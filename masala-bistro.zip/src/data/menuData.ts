export interface MenuItem {
  id: string;
  name: string;
  hindiName?: string;
  description: string;
  category: MenuCategory;
  isVeg: boolean;
  isChefSpecial?: boolean;
  spiceLevel?: 'Mild' | 'Medium' | 'Rich & Spicy';
  dietaryNote?: string;
  originOrStyle?: string;
  tags?: string[];
}

export type MenuCategory =
  | 'Indian Favourites'
  | 'Mughlai'
  | 'Tandoori & Kebab'
  | 'Chinese & Asian'
  | 'Rolls & Fast Food'
  | 'Continental';

export interface CategoryInfo {
  id: MenuCategory;
  title: string;
  subtitle: string;
  description: string;
  accentColor: string;
  illustrationNote: string;
}

export const MENU_CATEGORIES: CategoryInfo[] = [
  {
    id: 'Indian Favourites',
    title: 'Indian Favourites',
    subtitle: 'Desi Khushboo',
    description: 'Slow-simmered home-style curries, rich lentil gravies and fresh clay-oven breads prepared with fragrant whole ground spices.',
    accentColor: '#C05634',
    illustrationNote: 'Simmering copper kadhai with creamy gravies and tempered cumin seeds',
  },
  {
    id: 'Mughlai',
    title: 'Mughlai Delicacies',
    subtitle: 'Dawat-e-Khaas',
    description: 'Heirloom recipes passed down through Awadhi and Mughal kitchens, scented with saffron, kewra, cardamom and crushed almonds.',
    accentColor: '#C8A265',
    illustrationNote: 'Royal handi with saffron strands, whole star anise and slivered pistachios',
  },
  {
    id: 'Tandoori & Kebab',
    title: 'Tandoori & Kebab',
    subtitle: 'Bhatti Se',
    description: 'Charcoal-fired skewers marinated in spiced mustard oil, hung curd and crushed whole spices, served with fresh mint chutney.',
    accentColor: '#B34928',
    illustrationNote: 'Charred skewers over embers with mint chutney droplet and lime wedge',
  },
  {
    id: 'Chinese & Asian',
    title: 'Chinese & Asian',
    subtitle: 'Wok Seared',
    description: 'High-flame tossed noodles, silken Manchurian sauces, and vibrant Indo-Chinese comfort with fiery chillies and scallions.',
    accentColor: '#6E826F',
    illustrationNote: 'Smoky wok with flash-seared vegetables, toasted sesame and scallions',
  },
  {
    id: 'Rolls & Fast Food',
    title: 'Rolls & Fast Food',
    subtitle: 'Bistro Bites',
    description: 'Flaky paratha rolls layered with spiced fillings, bistro burgers, loaded accompaniments and quick gourmet comfort.',
    accentColor: '#D96B43',
    illustrationNote: 'Golden griddled flaky roll wrapped with fresh pickled onion rings',
  },
  {
    id: 'Continental',
    title: 'Continental',
    subtitle: 'Global Comfort',
    description: 'Velvety herb-infused pastas, slow-stirred risottos, wood-fired artisan garlic breads and wholesome garden plates.',
    accentColor: '#9E7B42',
    illustrationNote: 'Swirled pasta with basil leaf, olive oil drizzle and cracked peppercorn',
  },
];

export const MENU_ITEMS: MenuItem[] = [
  // 1. Indian Favourites
  {
    id: 'dal-makhani-masala',
    name: 'Dal Makhani Awadhi',
    hindiName: 'दाल मखनी',
    description: 'Black lentils slow-cooked overnight over simmering embers with fresh churned butter, organic tomato purée and aromatic fenugreek.',
    category: 'Indian Favourites',
    isVeg: true,
    isChefSpecial: true,
    spiceLevel: 'Mild',
    dietaryNote: 'House Signature · Slow Cooked 18 Hours',
    originOrStyle: 'Traditional Clay Pot Style',
    tags: ['Signature', 'Pure Butter', 'Bestseller'],
  },
  {
    id: 'paneer-tikka-lababdar',
    name: 'Paneer Lababdar',
    hindiName: 'पनीर लबाबदार',
    description: 'Soft cottage cheese cubes enveloped in a velvety tomato-cashew reduction accented with crushed coriander and cream.',
    category: 'Indian Favourites',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Rich Cashew Cream Gravy',
    originOrStyle: 'North Indian Classic',
    tags: ['Popular', 'Vegetarian Favorite'],
  },
  {
    id: 'butter-chicken-delicacy',
    name: 'Purani Dilli Butter Chicken',
    hindiName: 'बटर चिकन',
    description: 'Tender tandoor-roasted chicken simmered in an aromatic satin tomato sauce infused with dried fenugreek and wild honey.',
    category: 'Indian Favourites',
    isVeg: false,
    isChefSpecial: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Contains Dairy & Cashew',
    originOrStyle: 'Heritage Delhi Recipe',
    tags: ['House Classic', 'Bestseller'],
  },
  {
    id: 'subz-handi-biryani',
    name: 'Dum Pukht Subz Biryani',
    hindiName: 'दम पुख्त सब्जी बिरयानी',
    description: 'Fragrant aged basmati rice layered with garden farm vegetables, brown shallots and whole spices, sealed with dough and slow-steamed.',
    category: 'Indian Favourites',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Served with Burani Garlic Raita',
    originOrStyle: 'Dum Style Cooking',
    tags: ['Dum Cooked', 'Fragrant Basmati'],
  },
  {
    id: 'kadhai-murgh-masala',
    name: 'Peshawari Kadhai Murgh',
    hindiName: 'कढ़ाई मुर्ग',
    description: 'Succulent chicken tossed in an iron wok with freshly pounded coriander seeds, dried red chillies, capsicum and ripe tomatoes.',
    category: 'Indian Favourites',
    isVeg: false,
    spiceLevel: 'Rich & Spicy',
    dietaryNote: 'Fresh Wok Tossed',
    originOrStyle: 'Rustic Iron Kadhai',
    tags: ['Spiced', 'Rustic Flavor'],
  },

  // 2. Mughlai
  {
    id: 'shahi-murg-korma',
    name: 'Shahi Murgh Korma',
    hindiName: 'शाही मुर्ग कोरमा',
    description: 'An emperor’s court delicacy cooked in browned onion paste, almond cream, green cardamom and gentle rose petal water.',
    category: 'Mughlai',
    isVeg: false,
    isChefSpecial: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Almond & Saffron Infusion',
    originOrStyle: 'Awadhi Darbari Tradition',
    tags: ['Royal Court', 'Mughlai Specialty'],
  },
  {
    id: 'nalli-nihari-khaas',
    name: 'Nihari Gosht Khaas',
    hindiName: 'निहारी गोश्त',
    description: 'Tender mutton cuts slow-braised in a deeply aromatic broth with thirty-two artisanal spices, ginger juliennes and fresh coriander.',
    category: 'Mughlai',
    isVeg: false,
    isChefSpecial: true,
    spiceLevel: 'Rich & Spicy',
    dietaryNote: 'Slow Stewed Overnight',
    originOrStyle: 'Historic Agra Kitchens',
    tags: ['Slow Cooked', 'Heirloom Recipe'],
  },
  {
    id: 'paneer-kundan-kalia',
    name: 'Paneer Kundan Kalia',
    hindiName: 'पनीर कुंदन कालिया',
    description: 'Golden-seared cottage cheese steeped in a regal turmeric, saffron and yoghurt gravy scented with star anise and mace.',
    category: 'Mughlai',
    isVeg: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Royal Vegetarian Preparation',
    originOrStyle: 'Nawabi Heritage',
    tags: ['Mild & Aromatic', 'Saffron Gravy'],
  },
  {
    id: 'galouti-kebab-platter',
    name: 'Melt-in-Mouth Galouti Seekh',
    hindiName: 'गलौटी सीक कबाब',
    description: 'Silken minced meat infused with raw papaya and secret potli spices, griddled on mahi tawa and served over mini saffron paratha.',
    category: 'Mughlai',
    isVeg: false,
    spiceLevel: 'Medium',
    dietaryNote: 'Ultra Tender Texture',
    originOrStyle: 'Lucknowi Royal Style',
    tags: ['Delicate', 'Signature Starter'],
  },

  // 3. Tandoori & Kebab
  {
    id: 'afghani-murg-tikka',
    name: 'Afghani Murgh Malai Tikka',
    hindiName: 'अफ़ग़ानी मुर्ग मलाई टिक्का',
    description: 'Boneless chicken steeped in clotted cream, green cardamom powder, mild cheese and roasted in intense tandoor embers.',
    category: 'Tandoori & Kebab',
    isVeg: false,
    isChefSpecial: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Melt-in-Mouth Cream Marinade',
    originOrStyle: 'Clay Oven Roasted',
    tags: ['Clay Tandoor', 'Smoky & Creamy'],
  },
  {
    id: 'dahi-ke-kebab',
    name: 'Dahi Ke Sholay Kebab',
    hindiName: 'दही के कबाब',
    description: 'Crisp golden patties of hung yoghurt, crushed green chillies, coriander and toasted bell peppers, with a soft creamy core.',
    category: 'Tandoori & Kebab',
    isVeg: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Crisp Shell, Silken Center',
    originOrStyle: 'Bistro Signature Appetizer',
    tags: ['Vegetarian Star', 'Delicate'],
  },
  {
    id: 'paneer-angara-tikka',
    name: 'Tandoori Paneer Angara',
    hindiName: 'पनीर अंगारा टिक्का',
    description: 'Plump farm paneer chunks marinated in crushed deghi mirch, carom seeds and mustard oil, charred to smoky perfection with bell peppers.',
    category: 'Tandoori & Kebab',
    isVeg: true,
    spiceLevel: 'Rich & Spicy',
    dietaryNote: 'Charred with Onions & Peppers',
    originOrStyle: 'High-Heat Charcoal Oven',
    tags: ['Smoky', 'Charcoal Roasted'],
  },
  {
    id: 'tandoori-bharwan-aloo',
    name: 'Tandoori Bharwan Aloo',
    hindiName: 'भरवां आलू तंदूरी',
    description: 'Hollowed potato barrels stuffed with seasoned dry fruits, crushed cottage cheese and herbs, roasted until crisp and golden.',
    category: 'Tandoori & Kebab',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Nuts & Herb Stuffing',
    originOrStyle: 'Rustic Tandoor Treat',
    tags: ['Vegetarian', 'Crunchy'],
  },

  // 4. Chinese & Asian
  {
    id: 'crispy-lotus-stem',
    name: 'Honey Chilli Crispy Lotus Stem',
    hindiName: 'क्रिस्पी लोटस स्टेम',
    description: 'Thinly sliced tender lotus root crisped in high heat, glazed with wild honey, roasted sesame seeds and crushed Kashmiri chillies.',
    category: 'Chinese & Asian',
    isVeg: true,
    isChefSpecial: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Sweet & Piquant Glaze',
    originOrStyle: 'Modern Asian Street Fusion',
    tags: ['Crunchy', 'Crowd Favorite'],
  },
  {
    id: 'chilli-paneer-bistro',
    name: 'Wok Charred Chilli Paneer',
    hindiName: 'चिल्ली पनीर',
    description: 'Fresh cottage cheese cubes tossed with dark soy, spring onion crisps, split green chillies and roasted garlic.',
    category: 'Chinese & Asian',
    isVeg: true,
    spiceLevel: 'Rich & Spicy',
    dietaryNote: 'Dry or Semi-Gravy Style',
    originOrStyle: 'Indo-Chinese Classic',
    tags: ['Wok Tossed', 'Spiced Garlic'],
  },
  {
    id: 'burnt-garlic-noodles',
    name: 'Burnt Garlic Hakka Noodles',
    hindiName: 'हक्का नूडल्स',
    description: 'Hand-pulled style wok noodles tossed on fierce flame with crunchy julienne vegetables, toasted garlic flakes and white pepper.',
    category: 'Chinese & Asian',
    isVeg: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Smoky High-Flame Wok Aroma',
    originOrStyle: 'Street Style Wok Craft',
    tags: ['Smoky Wok', 'Classic Comfort'],
  },
  {
    id: 'steamed-dim-sum',
    name: 'Artisanal Steamed Dim Sum Basket',
    hindiName: 'डिम सम बास्केट',
    description: 'Translucent parcels hand-pinched with seasoned wild mushrooms, water chestnuts and garden greens, served with fiery tomato scallion dip.',
    category: 'Chinese & Asian',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Freshly Steamed to Order',
    originOrStyle: 'Bamboo Steamer Classic',
    tags: ['Steamed', 'Light & Fresh'],
  },

  // 5. Rolls & Fast Food
  {
    id: 'kolkata-kathi-roll',
    name: 'Kolkata Kathi Roll Masala',
    hindiName: 'कोलकाता काठी रोल',
    description: 'Flaky layered griddle paratha brushed with egg or spiced herb butter, wrapped around succulent paneer or chicken tikka with spiced onions.',
    category: 'Rolls & Fast Food',
    isVeg: false,
    isChefSpecial: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Fresh Pickled Onions & Chaat Masala',
    originOrStyle: 'Iconic Indian Street Craft',
    tags: ['Crisp Paratha', 'On-the-go Comfort'],
  },
  {
    id: 'masala-bistro-burger',
    name: 'The Masala Bistro Craft Burger',
    hindiName: 'मसाला बिस्ट्रो बर्गर',
    description: 'Artisan toasted brioche bun loaded with a double herb patty, house mint mayonnaise, melted cheddar, caramelized onions and crisp greens.',
    category: 'Rolls & Fast Food',
    isVeg: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Served with Golden Salted Wedges',
    originOrStyle: 'Bistro Fusion Classic',
    tags: ['Brioche Bun', 'Gourmet Burger'],
  },
  {
    id: 'peri-peri-fries-loaded',
    name: 'Spice Dusted Bistro Fries',
    hindiName: 'पेरी पेरी फ्राइज़',
    description: 'Golden hand-cut potato batons dusted in tangy roasted spice blend, accompanied by house garlic aioli and smoked barbecue dip.',
    category: 'Rolls & Fast Food',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Vegetarian Finger Food',
    originOrStyle: 'All-Day Bistro Munch',
    tags: ['Crispy', 'Snack Favorite'],
  },

  // 6. Continental
  {
    id: 'penne-arrabbiata-herb',
    name: 'Penne All’Arrabbiata Rustica',
    hindiName: 'पेने अरेबियाता',
    description: 'Bronze-die durum wheat penne tossed in San Marzano tomato reduction, extra virgin olive oil, garlic slivers, basil and chilli flakes.',
    category: 'Continental',
    isVeg: true,
    spiceLevel: 'Medium',
    dietaryNote: 'Tossed with Fresh Basil & Grated Parmesan',
    originOrStyle: 'Italian Classic',
    tags: ['Herb Infused', 'Olive Oil Tossed'],
  },
  {
    id: 'wild-mushroom-risotto',
    name: 'Truffle & Porcini Herb Risotto',
    hindiName: 'मशरूम रिसोटो',
    description: 'Slow-simmered arborio rice with woodland mushrooms, vegetable herb bouillon, creamy butter and aged parmesan shavings.',
    category: 'Continental',
    isVeg: true,
    isChefSpecial: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Silken Creamy Consistency',
    originOrStyle: 'Slow Stirred Continental',
    tags: ['Gourmet', 'Truffle Aroma'],
  },
  {
    id: 'wood-fired-garlic-bread',
    name: 'Rustic Pull-Apart Garlic Bread',
    hindiName: 'गार्लिक ब्रेड',
    description: 'Warm crusty artisan baguette infused with roasted garlic confit, salted farm butter, fresh parsley and bubbling mozzarella.',
    category: 'Continental',
    isVeg: true,
    spiceLevel: 'Mild',
    dietaryNote: 'Baked Golden Crisp',
    originOrStyle: 'Oven Baked Herb Bread',
    tags: ['Cheese Pull', 'Table Sharing'],
  },
];
