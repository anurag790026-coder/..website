import React from 'react';
import bistroInteriorPhoto from '../assets/images/real_bistro_interior_1789097617630.jpg';
import { Utensils, ShoppingBag, Truck, Flame, Users, Sparkles } from 'lucide-react';

interface ExperienceProps {
  onOpenReservation: () => void;
}

export const Experience: React.FC<ExperienceProps> = ({ onOpenReservation }) => {
  const experiences = [
    {
      title: 'Dine In',
      subtitle: 'Table Hospitality',
      description: 'A relaxed setting for family meals, dates and casual evenings.',
      icon: <Utensils className="w-5 h-5" />,
      accent: '#C8A265',
      timing: 'Lunch 12:00 PM – 3:30 PM · Dinner 7:00 PM – 11:30 PM',
      highlight: 'Warm candle glow, soothing acoustic rhythms & unhurried service.',
    },
    {
      title: 'Takeaway',
      subtitle: 'Curbside & Counter',
      description: 'Your favourites packed to enjoy wherever you are.',
      icon: <ShoppingBag className="w-5 h-5" />,
      accent: '#C05634',
      timing: 'Fast packing · Freshly prepared to order',
      highlight: 'Aromatic steam-locked containers preserving peak taste.',
    },
    {
      title: 'Delivery',
      subtitle: 'Bistro to Doorstep',
      description: 'Comfort food delivered when you want it.',
      icon: <Truck className="w-5 h-5" />,
      accent: '#6E826F',
      timing: 'Direct call orders across Tajganj & nearby Agra zones',
      highlight: 'Generous portions, spill-safe packaging and prompt dispatch.',
    },
  ];

  return (
    <section
      id="experience"
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 bg-[#110F0D] overflow-hidden border-t border-b border-[#241E1A]"
    >
      {/* Warm Ambience Lighting Background Effects */}
      <div className="absolute top-1/3 right-10 w-[500px] h-[500px] bg-[#E5C384]/07 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-[#C05634]/07 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Headline */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#C8A265]" />
            <span className="font-sans text-xs uppercase tracking-[0.3em] text-[#C8A265] font-semibold">
              The Bistro Atmosphere
            </span>
            <span className="w-6 h-[1px] bg-[#C8A265]" />
          </div>

          <h2 className="font-serif-heading text-4xl sm:text-6xl font-normal text-[#F8F4EC] leading-[1.15] tracking-tight">
            Warm lights. <br />
            <span className="italic font-display text-gold-gradient">Big flavours.</span>
          </h2>
          <p className="mt-4 text-[#A89E90] text-sm sm:text-base font-light max-w-xl mx-auto">
            Thoughtfully curated spaces, inviting candlelight and genuine hospitality tailored for memorable Agra evenings.
          </p>
        </div>

        {/* Real Bistro Dining Interior Photograph Showcase */}
        <div className="relative rounded-3xl overflow-hidden border border-[#C8A265]/30 mb-16 shadow-2xl bg-[#1A1614] max-w-5xl mx-auto group">
          <div className="relative aspect-video sm:aspect-[21/9] w-full">
            <img
              src={bistroInteriorPhoto}
              alt="Real dining room ambiance at Masala Bistro Tajganj Agra with warm candlelight and amber lamps"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#110F0D] via-[#110F0D]/30 to-transparent" />

            <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
              <div>
                <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#E5C384] block mb-1">
                  Fatehabad Road Dining Room
                </span>
                <p className="font-serif-heading text-xl sm:text-2xl text-[#F8F4EC] font-medium">
                  An intimate refuge with authentic warmth and amber light.
                </p>
              </div>

              <button
                type="button"
                onClick={onOpenReservation}
                className="px-6 py-2.5 rounded-full bg-[#C8A265]/90 hover:bg-[#C8A265] text-[#141210] font-sans font-semibold text-xs uppercase tracking-[0.2em] transition-all cursor-pointer shadow-lg"
              >
                Plan a Visit
              </button>
            </div>
          </div>
        </div>

        {/* Three Exact Feature Cards: Dine In, Takeaway, Delivery */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {experiences.map((item) => (
            <div
              key={item.title}
              className="relative rounded-2xl p-8 bg-[#181412] border border-[#2B231D] hover:border-[#C8A265]/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl flex flex-col justify-between"
            >
              <div>
                {/* Accent Icon Pill */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-6"
                  style={{
                    backgroundColor: `${item.accent}18`,
                    color: item.accent,
                    border: `1px solid ${item.accent}35`,
                  }}
                >
                  {item.icon}
                </div>

                <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#9E9486]">
                  {item.subtitle}
                </span>

                <h3 className="font-serif-heading text-2xl text-[#F8F4EC] font-medium mt-1 mb-3">
                  {item.title}
                </h3>

                <p className="text-sm text-[#CDC5B8] font-light leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              <div className="pt-4 border-t border-[#29221C] space-y-2">
                <p className="text-xs text-[#A89E90] font-serif italic">
                  {item.highlight}
                </p>
                <p className="text-[11px] text-[#C8A265] font-sans tracking-wide">
                  {item.timing}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
