import React from 'react';
import { Compass, UtensilsCrossed, ArrowDown, MapPin, Sparkles } from 'lucide-react';
import heroArt from '../assets/images/bistro_hero_art_1789097040489.jpg';

interface HeroProps {
  onExploreMenu: () => void;
  onGetDirections: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onGetDirections }) => {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#141210]"
    >
      {/* Ambient Lighting & Luxury Gradients */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Warm Golden Halo from Top Right */}
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#C8A265]/10 rounded-full blur-[140px] pointer-events-none" />
        {/* Terracotta Burnt Spice Aura from Bottom Left */}
        <div className="absolute -bottom-20 left-10 w-[450px] h-[450px] bg-[#C05634]/12 rounded-full blur-[160px] pointer-events-none" />
        {/* Subtle Espresso Vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#141210] via-transparent to-[#141210]/60" />
      </div>

      {/* Floating Animated Spice Particles & Steam in Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
        {/* Star Anise Floating Particle 1 */}
        <div className="absolute top-[20%] left-[8%] animate-float-gentle opacity-40">
          <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
            <polygon
              points="20,0 24,12 36,6 30,18 40,26 28,28 30,40 20,32 10,40 12,28 0,26 10,18 4,6 16,12"
              fill="#C8A265"
              opacity="0.6"
            />
            <circle cx="20" cy="20" r="3" fill="#E5C384" />
          </svg>
        </div>

        {/* Cardamom Pod Particle 2 */}
        <div className="absolute top-[65%] left-[5%] animate-float-gentle opacity-30" style={{ animationDelay: '2.5s' }}>
          <svg width="28" height="28" viewBox="0 0 30 30" fill="none">
            <path
              d="M15 3 C9 8, 8 20, 15 27 C22 20, 21 8, 15 3 Z"
              stroke="#C8A265"
              strokeWidth="1.5"
              fill="#26201B"
            />
            <line x1="15" y1="5" x2="15" y2="25" stroke="#E5C384" strokeWidth="1" strokeDasharray="2 2" />
          </svg>
        </div>

        {/* Delicate Cinnamon Quill Accent 3 */}
        <div className="absolute top-[28%] right-[6%] animate-float-gentle opacity-35" style={{ animationDelay: '1.5s' }}>
          <svg width="40" height="40" viewBox="0 0 50 50" fill="none">
            <path
              d="M10 40 Q25 25 40 10"
              stroke="#C05634"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            <path
              d="M13 43 Q28 28 43 13"
              stroke="#9E7B42"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center z-10">
        {/* Left Column: Narrative Headline & Actions */}
        <div className="lg:col-span-7 flex flex-col items-start text-left space-y-6 sm:space-y-8">
          {/* Subtle Agra Heritage Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#C8A265]/35 bg-[#1F1A16]/90 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-[#C8A265] animate-pulse" />
            <span className="text-[11px] font-medium uppercase tracking-[0.24em] text-[#E5C384]">
              Fatehabad Road · Tajganj · Agra
            </span>
          </div>

          {/* Primary Dramatic Headline */}
          <h1 className="font-serif-heading text-4xl sm:text-6xl xl:text-7xl font-semibold leading-[1.1] tracking-tight text-[#F8F4EC]">
            Flavours with <br />
            <span className="italic font-normal font-display text-gold-gradient">
              a little soul.
            </span>
          </h1>

          {/* Supporting Text */}
          <p className="font-sans text-base sm:text-lg text-[#CDC5B8] max-w-xl font-light leading-relaxed">
            A relaxed bistro in the heart of Tajganj, bringing generous plates,
            aromatic spices and warm hospitality to every table.
          </p>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
            {/* Explore Menu CTA */}
            <button
              id="hero-explore-menu-btn"
              type="button"
              onClick={onExploreMenu}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#C8A265] text-[#141210] font-sans font-semibold text-xs uppercase tracking-[0.24em] transition-all duration-300 hover:bg-[#E5C384] hover:shadow-xl hover:shadow-[#C8A265]/25 hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
            >
              <UtensilsCrossed className="w-4 h-4" />
              <span>Explore the Menu</span>
            </button>

            {/* Get Directions CTA */}
            <button
              id="hero-get-directions-btn"
              type="button"
              onClick={onGetDirections}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full border border-[#C8A265]/40 bg-[#1F1A16]/80 text-[#F8F4EC] font-sans font-medium text-xs uppercase tracking-[0.24em] transition-all duration-300 hover:border-[#C8A265] hover:bg-[#C8A265]/10 hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
            >
              <Compass className="w-4 h-4 text-[#C8A265]" />
              <span>Get Directions</span>
            </button>
          </div>

          {/* Quick Context Feature Notes */}
          <div className="pt-6 border-t border-[#332A24] flex flex-wrap items-center gap-6 text-xs text-[#A89E90]">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C8A265]" />
              <span>Multi-Cuisine Bistro</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C05634]" />
              <span>Authentic Spices</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#6E826F]" />
              <span>Dine-In · Takeaway · Delivery</span>
            </div>
          </div>
        </div>

        {/* Right Column: Beautiful Stylized Food Composition Illustration */}
        <div className="lg:col-span-5 relative flex justify-center items-center">
          {/* Circular Architectural Frame */}
          <div className="relative w-full max-w-md aspect-square sm:aspect-[4/5] rounded-3xl p-3 sm:p-4 bg-gradient-to-b from-[#C8A265]/30 via-[#26201B] to-[#161311] border border-[#C8A265]/35 shadow-2xl shadow-black/80">
            {/* The Stylized Food Artwork */}
            <div className="relative w-full h-full rounded-2xl overflow-hidden bg-[#161311]">
              <img
                src={heroArt}
                alt="Artistic culinary composition of Masala Bistro delicacies and aromatic spices"
                className="w-full h-full object-cover object-center transform transition-transform duration-700 hover:scale-105"
                referrerPolicy="no-referrer"
              />
              
              {/* Subtle Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#141210]/80 via-transparent to-transparent pointer-events-none" />

              {/* Floating Artistic Caption Pill */}
              <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-[#141210]/90 backdrop-blur-md border border-[#C8A265]/30 flex items-center justify-between">
                <div>
                  <p className="font-serif-heading text-sm text-[#F8F4EC] font-medium">Aromatic Masala Blend</p>
                  <p className="font-sans text-[11px] text-[#C8A265] tracking-wider">Hand-ground in Tajganj</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#C8A265]/15 flex items-center justify-center text-[#C8A265]">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Decorative Corner Ornaments */}
            <div className="absolute -top-2 -right-2 w-7 h-7 border-t-2 border-r-2 border-[#C8A265] rounded-tr-lg pointer-events-none" />
            <div className="absolute -bottom-2 -left-2 w-7 h-7 border-b-2 border-l-2 border-[#C8A265] rounded-bl-lg pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Subtle Scroll Down Anchor */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 hidden sm:flex flex-col items-center gap-1.5 opacity-60 hover:opacity-100 transition-opacity">
        <span className="text-[10px] font-sans uppercase tracking-[0.3em] text-[#C8A265]">Scroll to Explore</span>
        <ArrowDown className="w-3.5 h-3.5 text-[#C8A265] animate-bounce" />
      </div>
    </section>
  );
};
