import React from 'react';

interface LogoProps {
  variant?: 'light' | 'dark' | 'gold';
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showSubtitle?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  variant = 'light',
  size = 'md',
  showSubtitle = true,
  className = '',
}) => {
  // Determine color palette based on theme context
  const isDarkCanvas = variant === 'light' || variant === 'gold';
  const primaryTextColor = isDarkCanvas ? '#F8F4EC' : '#1F1A17';
  const goldColor = '#C8A265';
  const goldBright = '#E5C384';
  const subtitleColor = isDarkCanvas ? '#C8A265' : '#9E7B42';
  const agraTagColor = isDarkCanvas ? '#A89E90' : '#736657';

  // Dimension scaling
  const scaleConfig = {
    sm: { icon: 34, title: 'text-base tracking-[0.25em]', sub: 'text-[9px] tracking-[0.3em]', gap: 'gap-2.5' },
    md: { icon: 44, title: 'text-lg tracking-[0.28em]', sub: 'text-[10px] tracking-[0.34em]', gap: 'gap-3' },
    lg: { icon: 56, title: 'text-2xl tracking-[0.3em]', sub: 'text-xs tracking-[0.38em]', gap: 'gap-3.5' },
    hero: { icon: 76, title: 'text-3xl sm:text-4xl tracking-[0.32em]', sub: 'text-xs sm:text-sm tracking-[0.42em]', gap: 'gap-4' },
  }[size];

  return (
    <div className={`inline-flex items-center ${scaleConfig.gap} select-none group ${className}`}>
      {/* Handcrafted Emblem SVG: "M" monogram + Handi cooking vessel + rising steam + spice leaves */}
      <div className="relative shrink-0 flex items-center justify-center transition-transform duration-500 group-hover:scale-105">
        <svg
          width={scaleConfig.icon}
          height={scaleConfig.icon}
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="overflow-visible"
        >
          <defs>
            {/* Antique Gold Metallic Gradient */}
            <linearGradient id="antiqueGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F3DCAC" />
              <stop offset="35%" stopColor="#C8A265" />
              <stop offset="70%" stopColor="#9E7B42" />
              <stop offset="100%" stopColor="#D8B574" />
            </linearGradient>

            {/* Subtle Glow Filter */}
            <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Outer Ornamental Ring with Antique Gold Accents */}
          <circle
            cx="50"
            cy="50"
            r="46"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.25"
            strokeDasharray="90 8 4 8"
            strokeOpacity="0.85"
          />
          <circle
            cx="50"
            cy="50"
            r="43"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="0.5"
            strokeOpacity="0.4"
          />

          {/* Rising Aromatic Steam Waves */}
          <path
            d="M44 26 C43 20, 48 18, 47 12"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeOpacity="0.75"
            className="animate-steam"
          />
          <path
            d="M52 28 C54 21, 49 19, 53 11"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeOpacity="0.9"
            className="animate-steam"
            style={{ animationDelay: '1.2s' }}
          />
          <path
            d="M59 26 C57 20, 62 17, 60 13"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.25"
            strokeLinecap="round"
            strokeOpacity="0.65"
            className="animate-steam"
            style={{ animationDelay: '2.4s' }}
          />

          {/* Subtle Star Anise / Botanical Spice Motif at Top */}
          <circle cx="50" cy="19" r="1.5" fill="#E5C384" />
          <path
            d="M49 19 L51 19 M50 18 L50 20"
            stroke="#C8A265"
            strokeWidth="0.8"
          />

          {/* Elegant "M" Monogram intertwined with the Indian Cooking Vessel */}
          {/* Handi / Kadhai Bowl Silhouette forming the Base */}
          <path
            d="M24 64 C24 78, 76 78, 76 64 C76 60, 71 58, 50 58 C29 58, 24 60, 24 64 Z"
            fill="url(#antiqueGoldGrad)"
            fillOpacity="0.16"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          {/* Subtle Handi Brass Rim */}
          <path
            d="M20 63 C20 60, 80 60, 80 63"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="1.4"
            strokeLinecap="round"
          />

          {/* Majestic Royal Serif "M" Monogram */}
          {/* Left Stem */}
          <path
            d="M29 64 L29 34 C29 32, 27 32, 26 32 M29 64 C27 64, 25 64, 24 64"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          {/* Right Stem */}
          <path
            d="M71 64 L71 34 C71 32, 73 32, 74 32 M71 64 C73 64, 75 64, 76 64"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          {/* Central Diagonals converging into an Indian Lotus/Vessel Peak */}
          <path
            d="M29 34 L50 54 L71 34"
            stroke="url(#antiqueGoldGrad)"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Central Flame / Saffron Stigma droplet inside the M valley */}
          <path
            d="M50 36 C47 43, 50 48, 50 49 C50 48, 53 43, 50 36 Z"
            fill="url(#antiqueGoldGrad)"
          />

          {/* Tiny Botanical Spice Leaf Accents on Left and Right Handles */}
          {/* Left Leaf Accent */}
          <path
            d="M17 62 C14 59, 15 54, 19 56 C20 59, 18 61, 17 62 Z"
            fill="#C8A265"
            opacity="0.8"
          />
          {/* Right Leaf Accent */}
          <path
            d="M83 62 C86 59, 85 54, 81 56 C80 59, 82 61, 83 62 Z"
            fill="#C8A265"
            opacity="0.8"
          />

          {/* Bottom Foundation Accent Bead */}
          <circle cx="50" cy="79" r="2" fill="url(#antiqueGoldGrad)" />
          <path d="M42 79 L46 79 M54 79 L58 79" stroke="#C8A265" strokeWidth="0.8" />
        </svg>
      </div>

      {/* Brand Typography Lockup */}
      <div className="flex flex-col">
        <span
          className={`font-serif-heading font-bold uppercase transition-colors duration-300 ${scaleConfig.title}`}
          style={{ color: primaryTextColor }}
        >
          Masala
        </span>
        {showSubtitle && (
          <div className="flex items-center gap-2 mt-0.5">
            <span
              className={`font-serif-heading font-semibold uppercase tracking-[0.32em] ${scaleConfig.sub}`}
              style={{ color: subtitleColor }}
            >
              Bistro
            </span>
            <span className="w-1 h-1 rounded-full bg-[#C8A265]/60" />
            <span
              className={`font-sans font-medium uppercase text-[8px] sm:text-[9px] tracking-[0.3em]`}
              style={{ color: agraTagColor }}
            >
              Agra
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
