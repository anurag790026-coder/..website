import React from 'react';
import mughlaiArt from '../assets/images/mughlai_craft_art_1789097055123.jpg';
import { Flame, Sparkles, HeartHandshake } from 'lucide-react';

export const Story: React.FC = () => {
  return (
    <section id="story" className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 bg-[#181412] overflow-hidden border-t border-[#29221C]">
      {/* Subtle Texture & Warm Lighting */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#C05634]/08 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#C8A265]/08 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        {/* Section Tagline */}
        <div className="flex items-center gap-3 mb-4">
          <span className="h-[1px] w-10 bg-[#C8A265]" />
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-[#C8A265] font-semibold">
            Our Story & Heritage
          </span>
        </div>

        {/* Primary Title */}
        <div className="max-w-3xl mb-16">
          <h2 className="font-serif-heading text-3xl sm:text-5xl lg:text-6xl font-normal text-[#F8F4EC] leading-[1.15] tracking-tight">
            Classic Indian comfort, <br />
            <span className="italic font-display text-gold-gradient">styled for today.</span>
          </h2>
        </div>

        {/* Editorial Two-Column Presentation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual Story Artwork Composition */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#C8A265]/30 bg-[#211B17] shadow-2xl">
              <img
                src={mughlaiArt}
                alt="Artisanal composition of Mughlai spices, tandoori skewers and slow-simmered gravies"
                className="w-full h-auto object-cover transform transition-transform duration-700 hover:scale-102"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#181412]/70 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Editorial Floating Quote Plaque */}
            <div className="mt-4 sm:mt-0 sm:absolute -bottom-6 -right-6 max-w-xs p-5 rounded-xl bg-[#211B17] border border-[#C8A265]/40 shadow-xl backdrop-blur-md">
              <p className="font-serif-heading italic text-sm text-[#F8F4EC] leading-relaxed">
                “Every curry has its own rhythm; spices are gently coaxed, never rushed.”
              </p>
              <p className="mt-2 text-[10px] font-sans uppercase tracking-[0.24em] text-[#C8A265]">
                Kitchen Philosophy · Tajganj
              </p>
            </div>
          </div>

          {/* Right Column: Thoughtful, Believable Editorial Prose */}
          <div className="lg:col-span-6 space-y-6 text-[#CDC5B8] font-sans font-light leading-relaxed text-base sm:text-lg">
            <p>
              Located along the lively corridor of Fatehabad Road in Tajganj,{' '}
              <strong className="font-normal text-[#F8F4EC]">Masala Bistro</strong> was born
              from an appreciation for the dishes that bring people together: generous clay-pot
              curries, charred tandoori kebabs, slow-perfumed biryanis, and comforting
              Asian-inspired favourites.
            </p>

            <p>
              Agra has long been a crossroads of grand imperial kitchens and everyday street-side
              warmth. We bring those two worlds into dialogue — taking the depth of slow-simmered
              Mughlai and North Indian cooking and pairing it with a clean, contemporary bistro feel
              that is romantic for couples and effortlessly welcoming for families.
            </p>

            <p className="text-sm sm:text-base text-[#A89E90]">
              Whether you stop by after walking the avenues of Tajganj or gather for an evening of
              shared plates, our kitchen focuses on honest ingredients, freshly ground masala pastes,
              and genuine warmth in every serve.
            </p>

            {/* Three Pillar Cards */}
            <div className="pt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-[#332A23]">
              <div className="p-4 rounded-xl bg-[#211B17]/70 border border-[#382F28]">
                <div className="w-8 h-8 rounded-lg bg-[#C05634]/15 flex items-center justify-center text-[#C05634] mb-3">
                  <Flame className="w-4 h-4" />
                </div>
                <h3 className="font-serif-heading text-sm text-[#F8F4EC] font-medium">Clay Tandoor</h3>
                <p className="text-xs text-[#9E9486] mt-1">Smoked on real charcoal embers.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#211B17]/70 border border-[#382F28]">
                <div className="w-8 h-8 rounded-lg bg-[#C8A265]/15 flex items-center justify-center text-[#C8A265] mb-3">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="font-serif-heading text-sm text-[#F8F4EC] font-medium">Hand-Ground</h3>
                <p className="text-xs text-[#9E9486] mt-1">Whole spices roasted daily.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#211B17]/70 border border-[#382F28]">
                <div className="w-8 h-8 rounded-lg bg-[#6E826F]/15 flex items-center justify-center text-[#6E826F] mb-3">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <h3 className="font-serif-heading text-sm text-[#F8F4EC] font-medium">Tajganj Hospitality</h3>
                <p className="text-xs text-[#9E9486] mt-1">Attentive, relaxed and warm.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
