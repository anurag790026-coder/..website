import React, { useState } from 'react';
import {
  MENU_CATEGORIES,
  MENU_ITEMS,
  MenuCategory,
  MenuItem,
} from '../data/menuData';
import { DishIllustration } from './DishIllustration';
import { X, Search, Flame, Sparkles, Phone, Printer } from 'lucide-react';

interface FullMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReservation: () => void;
}

export const FullMenuModal: React.FC<FullMenuModalProps> = ({
  isOpen,
  onClose,
  onOpenReservation,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [vegOnly, setVegOnly] = useState(false);

  if (!isOpen) return null;

  const filteredItems = MENU_ITEMS.filter((dish) => {
    const matchesCategory = selectedFilter === 'All' || dish.category === selectedFilter;
    const matchesSearch =
      dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (dish.hindiName && dish.hindiName.includes(searchQuery));
    const matchesVeg = !vegOnly || dish.isVeg;
    return matchesCategory && matchesSearch && matchesVeg;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#161311] border border-[#C8A265]/40 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-[#F8F4EC]">
        {/* Modal Header */}
        <div className="p-6 border-b border-[#2C241E] flex items-center justify-between bg-[#1A1613]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#C8A265]">
              Tajganj, Agra · Complete Dining Repertoire
            </span>
            <h3 className="font-serif-heading text-2xl sm:text-3xl text-[#F8F4EC] font-semibold">
              The Masala Bistro Menu
            </h3>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => window.print()}
              className="hidden sm:inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-[#3A3027] text-xs text-[#A89E90] hover:text-[#F8F4EC] hover:border-[#C8A265]"
              title="Print menu"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full border border-[#3A3027] hover:border-[#C8A265] text-[#CDC5B8] hover:text-[#F8F4EC] transition-colors"
              aria-label="Close full menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="p-4 sm:p-6 bg-[#181412] border-b border-[#2C241E] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#A89E90] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search dishes (e.g., Dal Makhani, Korma, Dim Sum)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-[#120F0D] border border-[#332A23] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none placeholder:text-[#6E6356]"
            />
          </div>

          {/* Veg Only Toggle */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-medium text-[#CDC5B8]">
              <input
                type="checkbox"
                checked={vegOnly}
                onChange={(e) => setVegOnly(e.target.checked)}
                className="w-4 h-4 rounded border-[#3A3027] text-[#C8A265] focus:ring-0 focus:ring-offset-0 bg-[#120F0D] cursor-pointer"
              />
              <span>Pure Veg Only</span>
            </label>
          </div>
        </div>

        {/* Category Pills */}
        <div className="px-6 py-3 bg-[#1A1613] border-b border-[#2C241E] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            type="button"
            onClick={() => setSelectedFilter('All')}
            className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs tracking-wider transition-colors ${
              selectedFilter === 'All'
                ? 'bg-[#C8A265] text-[#141210] font-semibold'
                : 'bg-[#241E19] text-[#A89E90] hover:text-[#F8F4EC]'
            }`}
          >
            All Selections ({MENU_ITEMS.length})
          </button>
          {MENU_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedFilter(cat.id)}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs tracking-wider transition-colors ${
                selectedFilter === cat.id
                  ? 'bg-[#C8A265] text-[#141210] font-semibold'
                  : 'bg-[#241E19] text-[#A89E90] hover:text-[#F8F4EC]'
              }`}
            >
              {cat.title}
            </button>
          ))}
        </div>

        {/* Scrollable Dish List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {filteredItems.length === 0 ? (
            <div className="text-center py-16 text-[#A89E90]">
              <p className="font-serif-heading text-xl">No dishes match your search.</p>
              <p className="text-xs mt-1">Try another keyword or view all categories.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredItems.map((dish) => (
                <div
                  key={dish.id}
                  className="p-5 rounded-xl bg-[#1D1815] border border-[#302720] hover:border-[#C8A265]/50 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                            dish.isVeg
                              ? 'border-emerald-500/80 bg-emerald-950/30'
                              : 'border-amber-600/80 bg-amber-950/30'
                          }`}
                        >
                          <div
                            className={`w-1.5 h-1.5 rounded-full ${
                              dish.isVeg ? 'bg-emerald-500' : 'bg-amber-600'
                            }`}
                          />
                        </div>
                        <h4 className="font-serif-heading text-lg text-[#F8F4EC] font-medium">
                          {dish.name}
                        </h4>
                      </div>

                      {dish.isChefSpecial && (
                        <span className="px-2 py-0.5 rounded-full bg-[#C8A265]/15 text-[#E5C384] text-[9px] font-semibold tracking-wider uppercase shrink-0">
                          Specialty
                        </span>
                      )}
                    </div>

                    {dish.hindiName && (
                      <p className="text-xs text-[#C8A265]/70 font-serif mb-2">
                        {dish.hindiName}
                      </p>
                    )}

                    <p className="text-xs text-[#CDC5B8] font-light leading-relaxed mb-3">
                      {dish.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#29211B] flex items-center justify-between text-[11px] text-[#A89E90]">
                    <span className="italic font-serif">{dish.dietaryNote || dish.category}</span>
                    {dish.spiceLevel && (
                      <span className="flex items-center gap-1 text-[#C8A265]">
                        <Flame className="w-3 h-3 text-[#C05634]" />
                        {dish.spiceLevel}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer Call to Action */}
        <div className="p-4 sm:p-6 bg-[#1A1613] border-t border-[#2C241E] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#A89E90] text-center sm:text-left">
            <span>Special dietary preferences or allergies? Speak with our team.</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <a
              href="tel:+919557761116"
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full border border-[#C8A265]/40 bg-[#211B17] text-[#F8F4EC] text-xs uppercase tracking-wider hover:border-[#C8A265]"
            >
              <Phone className="w-3.5 h-3.5 text-[#C8A265]" />
              <span>Call +91 95577 61116</span>
            </a>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenReservation();
              }}
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-full bg-[#C8A265] text-[#141210] font-sans font-bold text-xs uppercase tracking-wider hover:bg-[#E5C384]"
            >
              Reserve Table
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
