import React, { useState } from 'react';
import {
  MENU_CATEGORIES,
  MENU_ITEMS,
  MenuCategory,
  MenuItem,
} from '../data/menuData';
import { DishIllustration } from './DishIllustration';
import dalNaanPhoto from '../assets/images/real_dal_naan_1789097580988.jpg';
import tandooriPhoto from '../assets/images/real_tandoori_kebab_1789097598920.jpg';
import biryaniPhoto from '../assets/images/real_handi_biryani_1789097632090.jpg';
import { Sparkles, Utensils, Flame, Leaf, ArrowRight, Camera } from 'lucide-react';

interface MenuShowcaseProps {
  onOpenFullMenu: () => void;
  onOpenReservation: () => void;
}

export const MenuShowcase: React.FC<MenuShowcaseProps> = ({
  onOpenFullMenu,
  onOpenReservation,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory>('Indian Favourites');

  const activeCategoryInfo = MENU_CATEGORIES.find((c) => c.id === selectedCategory) || MENU_CATEGORIES[0];
  const categoryDishes = MENU_ITEMS.filter((item) => item.category === selectedCategory);

  const realSignaturePlates = [
    {
      title: 'Awadhi Dal Makhani & Garlic Naan',
      sub: 'Slow-simmered for 16 hours on charcoal',
      image: dalNaanPhoto,
      tag: 'Guest Favourite',
      desc: 'Black lentils slow-cooked with fresh churned white butter, cream, and roasted fenugreek, served with blistered tandoori garlic naan.',
    },
    {
      title: 'Charcoal Tandoori Kebab Platter',
      sub: 'Clay tandoor skewers & mint relish',
      image: tandooriPhoto,
      tag: 'Chef Signature',
      desc: 'Smoked chicken tikka and spiced seekh kebabs charred on open charcoal embers with fresh coriander, onion rings, and lemon.',
    },
    {
      title: 'Dum Pukht Handi Biryani',
      sub: 'Fragrant saffron rice sealed in clay pot',
      image: biryaniPhoto,
      tag: 'Heritage Recipe',
      desc: 'Long-grain aged basmati layered with tender cuts, roasted whole spices, and golden caramelized onions, paired with chilled raita.',
    },
  ];

  return (
    <section
      id="menu"
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 bg-[#141210] overflow-hidden"
    >
      {/* Background Decorative Accents */}
      <div className="absolute -top-32 right-10 w-96 h-96 bg-[#C8A265]/06 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-32 left-10 w-96 h-96 bg-[#C05634]/08 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#C8A265]" />
            <span className="font-sans text-xs uppercase tracking-[0.3em] text-[#C8A265] font-semibold">
              The Bistro Kitchen
            </span>
            <span className="w-6 h-[1px] bg-[#C8A265]" />
          </div>
          <h2 className="font-serif-heading text-3xl sm:text-5xl font-normal text-[#F8F4EC] tracking-tight">
            Curated Menu Selections
          </h2>
          <p className="mt-4 text-[#A89E90] text-sm sm:text-base font-light">
            From clay-tandoor roasts and velvety gravies to high-heat wok specials, crafted with hand-ground spices in Tajganj.
          </p>
        </div>

        {/* Real Plates Gallery: Building Authentic Trust & Believability */}
        <div className="mb-20">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#E5C384] font-medium">
              <Camera className="w-4 h-4 text-[#C8A265]" />
              <span>Authentic Table Plates · Fresh from Our Kitchen</span>
            </div>
            <span className="text-xs text-[#807466] hidden sm:inline">
              Daily Service in Tajganj
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {realSignaturePlates.map((plate) => (
              <div
                key={plate.title}
                className="group rounded-2xl overflow-hidden bg-[#1B1714] border border-[#302720] hover:border-[#C8A265]/60 transition-all duration-300 shadow-xl flex flex-col"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-[#120F0E]">
                  <img
                    src={plate.image}
                    alt={plate.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1B1714] via-transparent to-transparent opacity-80" />
                  <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-[#141210]/80 backdrop-blur-md border border-[#C8A265]/40 text-[#E5C384] text-[10px] uppercase tracking-wider font-semibold">
                    {plate.tag}
                  </span>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#C8A265] block mb-1">
                      {plate.sub}
                    </span>
                    <h3 className="font-serif-heading text-xl text-[#F8F4EC] font-medium mb-2 group-hover:text-[#E5C384] transition-colors">
                      {plate.title}
                    </h3>
                    <p className="text-xs text-[#B5ABA0] font-light leading-relaxed">
                      {plate.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 mb-12 scrollbar-none gap-2 sm:gap-3">
          {MENU_CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`whitespace-nowrap px-5 py-3 rounded-full text-xs uppercase tracking-[0.2em] font-medium transition-all duration-300 cursor-pointer ${
                  isActive
                    ? 'bg-[#C8A265] text-[#141210] font-semibold shadow-lg shadow-[#C8A265]/20 scale-102'
                    : 'bg-[#1C1815] text-[#CDC5B8] border border-[#332A23] hover:border-[#C8A265]/50 hover:text-[#F8F4EC]'
                }`}
              >
                {cat.title}
              </button>
            );
          })}
        </div>

        {/* Active Category Editorial Spotlight Banner */}
        <div className="relative rounded-2xl p-6 sm:p-8 mb-10 bg-gradient-to-r from-[#211B17] via-[#1C1815] to-[#26201B] border border-[#C8A265]/25 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8A265]/15 border border-[#C8A265]/30 mb-2">
              <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#E5C384]">
                {activeCategoryInfo.subtitle}
              </span>
            </div>
            <h3 className="font-serif-heading text-2xl sm:text-3xl text-[#F8F4EC] font-medium">
              {activeCategoryInfo.title}
            </h3>
            <p className="mt-2 text-[#CDC5B8] text-sm font-light max-w-xl">
              {activeCategoryInfo.description}
            </p>
          </div>

          {/* Category Graphic Composition */}
          <div className="shrink-0 flex items-center justify-center p-2 rounded-2xl bg-[#141210]/60 border border-[#C8A265]/20">
            <DishIllustration category={selectedCategory} size="md" />
          </div>
        </div>

        {/* Featured Dish Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {categoryDishes.map((dish) => (
            <div
              key={dish.id}
              className="group relative rounded-2xl p-6 bg-[#1A1614] border border-[#332B24] hover:border-[#C8A265]/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/60 flex flex-col justify-between"
            >
              <div>
                {/* Header: Dietary Marker & Chef Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    {/* Authentic Veg / Non-Veg Indicator symbol */}
                    <div
                      className={`w-4 h-4 rounded border flex items-center justify-center ${
                        dish.isVeg
                          ? 'border-emerald-500/80 bg-emerald-950/30'
                          : 'border-amber-600/80 bg-amber-950/30'
                      }`}
                      title={dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
                    >
                      <div
                        className={`w-2 h-2 rounded-full ${
                          dish.isVeg ? 'bg-emerald-500' : 'bg-amber-600'
                        }`}
                      />
                    </div>
                    <span className="text-[11px] font-sans tracking-wider text-[#A89E90]">
                      {dish.isVeg ? 'Vegetarian' : 'Chef’s Roast'}
                    </span>
                  </div>

                  {dish.isChefSpecial && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#C8A265]/20 text-[#E5C384] text-[10px] font-semibold tracking-wider">
                      <Sparkles className="w-3 h-3" />
                      Specialty
                    </span>
                  )}
                </div>

                {/* Dish Name & Hindi Script */}
                <div className="mb-2">
                  <h4 className="font-serif-heading text-xl text-[#F8F4EC] group-hover:text-[#E5C384] transition-colors duration-200">
                    {dish.name}
                  </h4>
                  {dish.hindiName && (
                    <span className="text-xs font-serif text-[#C8A265]/75 tracking-wider">
                      {dish.hindiName}
                    </span>
                  )}
                </div>

                {/* Evocative Description */}
                <p className="text-sm text-[#CDC5B8] font-light leading-relaxed mb-4">
                  {dish.description}
                </p>
              </div>

              {/* Card Footer: Spice, Preparation & Notes */}
              <div className="pt-4 border-t border-[#2B231D] flex items-center justify-between text-xs">
                <span className="text-[#A89E90] italic font-serif">
                  {dish.dietaryNote || dish.originOrStyle}
                </span>

                {dish.spiceLevel && (
                  <span className="inline-flex items-center gap-1 text-[11px] text-[#C8A265] font-sans">
                    <Flame className="w-3.5 h-3.5 text-[#C05634]" />
                    {dish.spiceLevel}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* View Full Menu CTA & Reserve Bar */}
        <div className="text-center p-8 rounded-2xl bg-[#1C1815] border border-[#C8A265]/30 max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-center sm:text-left">
            <h4 className="font-serif-heading text-xl text-[#F8F4EC]">
              Looking for our complete selection?
            </h4>
            <p className="text-xs sm:text-sm text-[#A89E90] mt-1 font-light">
              Explore our full dining repertoire including breads, desserts & beverages.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              id="view-full-menu-cta-btn"
              type="button"
              onClick={onOpenFullMenu}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#C8A265] text-[#141210] font-sans font-semibold text-xs uppercase tracking-[0.2em] hover:bg-[#E5C384] transition-all cursor-pointer shadow-md"
            >
              <span>View Full Menu</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
