import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Phone, Menu as MenuIcon, X, Calendar, MapPin } from 'lucide-react';

interface NavbarProps {
  onOpenReservation: () => void;
  onOpenFullMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenReservation, onOpenFullMenu }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Our Story', href: '#story' },
    { name: 'Menu', href: '#menu' },
    { name: 'Experience', href: '#experience' },
    { name: 'Visit', href: '#location' },
  ];

  const handleLinkClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header
        id="main-navbar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#141210]/95 backdrop-blur-md py-3.5 border-b border-[#C8A265]/20 shadow-xl shadow-black/40'
            : 'bg-gradient-to-b from-[#141210]/90 via-[#141210]/40 to-transparent py-5 sm:py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#" className="focus:outline-none" aria-label="Masala Bistro Home">
              <Logo size="md" variant="light" />
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="font-sans text-xs uppercase tracking-[0.24em] text-[#E8E2D5] hover:text-[#C8A265] transition-colors duration-200 py-1 relative group"
                >
                  {link.name}
                  <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#C8A265] transition-all duration-300 group-hover:w-full" />
                </a>
              ))}

              <button
                type="button"
                onClick={onOpenFullMenu}
                className="font-sans text-xs uppercase tracking-[0.24em] text-[#C8A265] hover:text-[#E5C384] transition-colors duration-200 py-1"
              >
                Full Menu
              </button>
            </nav>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center space-x-4">
              {/* Call to Reserve Link */}
              <a
                id="nav-phone-call-btn"
                href="tel:+919557761116"
                className="flex items-center gap-2.5 px-3.5 py-2 rounded-full border border-[#C8A265]/35 bg-[#1F1A16]/80 text-[#E8E2D5] hover:text-[#F8F4EC] hover:border-[#C8A265] hover:bg-[#C8A265]/15 transition-all duration-300 text-xs tracking-wider"
                title="Call Masala Bistro: +91 95577 61116"
              >
                <span className="w-6 h-6 rounded-full bg-[#C8A265]/20 flex items-center justify-center text-[#C8A265]">
                  <Phone className="w-3.5 h-3.5" />
                </span>
                <span className="font-sans font-medium text-xs tracking-[0.14em]">+91 95577 61116</span>
              </a>

              {/* Call to Reserve / Booking CTA */}
              <button
                id="nav-reserve-modal-btn"
                type="button"
                onClick={onOpenReservation}
                className="relative inline-flex items-center justify-center px-5 py-2.5 rounded-full overflow-hidden text-xs font-semibold uppercase tracking-[0.2em] transition-all duration-300 bg-[#C8A265] text-[#141210] hover:bg-[#E5C384] hover:shadow-lg hover:shadow-[#C8A265]/20 active:scale-95"
              >
                Call to Reserve
              </button>
            </div>

            {/* Mobile Actions: Call Button & Hamburger */}
            <div className="flex items-center space-x-2 md:hidden">
              <a
                href="tel:+919557761116"
                aria-label="Call +91 95577 61116"
                className="p-2.5 rounded-full border border-[#C8A265]/40 bg-[#1F1A16] text-[#C8A265] hover:bg-[#C8A265] hover:text-[#141210] transition-colors"
              >
                <Phone className="w-4 h-4" />
              </a>

              <button
                id="mobile-nav-toggle-btn"
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2.5 rounded-lg border border-[#38302A] bg-[#1A1614] text-[#E8E2D5] hover:text-[#C8A265] focus:outline-none"
                aria-expanded={mobileMenuOpen}
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="fixed inset-0 z-40 bg-[#141210]/98 backdrop-blur-xl pt-24 px-6 pb-8 flex flex-col justify-between md:hidden animate-in fade-in duration-300"
        >
          {/* Subtle Decorative Gold Accent Line */}
          <div className="w-16 h-[1.5px] bg-[#C8A265]/40 mb-6" />

          <nav className="flex flex-col space-y-5">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={handleLinkClick}
                className="font-serif-heading text-2xl tracking-wider text-[#F8F4EC] hover:text-[#C8A265] transition-colors"
              >
                {link.name}
              </a>
            ))}

            <button
              type="button"
              onClick={() => {
                handleLinkClick();
                onOpenFullMenu();
              }}
              className="font-serif-heading text-2xl text-left tracking-wider text-[#C8A265]"
            >
              Full Menu Showcase
            </button>
          </nav>

          {/* Mobile Drawer Bottom Contact & Action */}
          <div className="mt-8 pt-6 border-t border-[#38302A] space-y-4">
            <div className="flex items-start gap-3 text-xs text-[#A89E90]">
              <MapPin className="w-4 h-4 text-[#C8A265] shrink-0 mt-0.5" />
              <span>304, Fatehabad Road, Vaibhav Nagar, Tajganj, Agra, UP 282001</span>
            </div>

            <a
              href="tel:+919557761116"
              className="flex items-center justify-center gap-3 w-full py-3.5 rounded-full border border-[#C8A265]/50 bg-[#1F1A16] text-[#F8F4EC] font-sans font-medium text-sm tracking-wider"
            >
              <Phone className="w-4 h-4 text-[#C8A265]" />
              Call to Reserve (+91 95577 61116)
            </a>

            <button
              type="button"
              onClick={() => {
                handleLinkClick();
                onOpenReservation();
              }}
              className="w-full py-3.5 rounded-full bg-[#C8A265] text-[#141210] font-sans font-bold text-xs uppercase tracking-[0.24em] shadow-lg shadow-[#C8A265]/20"
            >
              Book Table Inquiry
            </button>
          </div>
        </div>
      )}
    </>
  );
};
