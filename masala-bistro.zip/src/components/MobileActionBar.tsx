import React from 'react';
import { Phone, Navigation, UtensilsCrossed, Calendar } from 'lucide-react';

interface MobileActionBarProps {
  onOpenFullMenu: () => void;
  onOpenReservation: () => void;
}

export const MobileActionBar: React.FC<MobileActionBarProps> = ({
  onOpenFullMenu,
  onOpenReservation,
}) => {
  const googleMapsUrl =
    'https://www.google.com/maps/search/?api=1&query=Masala+Bistro+304+Fatehabad+Road+Vaibhav+Nagar+Tajganj+Agra+Uttar+Pradesh+282001';

  return (
    <div
      id="mobile-persistent-action-bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#161311]/95 backdrop-blur-lg border-t border-[#C8A265]/30 px-3 py-2.5 md:hidden shadow-2xl shadow-black"
    >
      <div className="grid grid-cols-4 gap-2 max-w-md mx-auto">
        {/* 1. Call Now */}
        <a
          id="mobile-bar-call-btn"
          href="tel:+919557761116"
          className="flex flex-col items-center justify-center min-h-[48px] py-1 px-1 rounded-xl bg-[#211B17] border border-[#382F27] text-[#E5C384] active:bg-[#C8A265] active:text-[#141210] transition-colors"
        >
          <Phone className="w-4 h-4" />
          <span className="text-[10px] font-sans font-semibold uppercase tracking-wider mt-1">
            Call
          </span>
        </a>

        {/* 2. Get Directions */}
        <a
          id="mobile-bar-directions-btn"
          href={googleMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center min-h-[48px] py-1 px-1 rounded-xl bg-[#211B17] border border-[#382F27] text-[#E8E2D5] active:bg-[#C8A265] active:text-[#141210] transition-colors"
        >
          <Navigation className="w-4 h-4 text-[#C8A265]" />
          <span className="text-[10px] font-sans font-medium uppercase tracking-wider mt-1">
            Directions
          </span>
        </a>

        {/* 3. Menu */}
        <button
          id="mobile-bar-menu-btn"
          type="button"
          onClick={onOpenFullMenu}
          className="flex flex-col items-center justify-center min-h-[48px] py-1 px-1 rounded-xl bg-[#211B17] border border-[#382F27] text-[#E8E2D5] active:bg-[#C8A265] active:text-[#141210] transition-colors cursor-pointer"
        >
          <UtensilsCrossed className="w-4 h-4 text-[#C05634]" />
          <span className="text-[10px] font-sans font-medium uppercase tracking-wider mt-1">
            Menu
          </span>
        </button>

        {/* 4. Reserve */}
        <button
          id="mobile-bar-reserve-btn"
          type="button"
          onClick={onOpenReservation}
          className="flex flex-col items-center justify-center min-h-[48px] py-1 px-1 rounded-xl bg-[#C8A265] text-[#141210] active:bg-[#E5C384] transition-colors cursor-pointer shadow-md"
        >
          <Calendar className="w-4 h-4" />
          <span className="text-[10px] font-sans font-bold uppercase tracking-wider mt-1">
            Reserve
          </span>
        </button>
      </div>
    </div>
  );
};
