import React from 'react';

export const SignatureQuote: React.FC = () => {
  return (
    <section className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 bg-[#F7F2E8] text-[#1D1814] overflow-hidden">
      {/* Subtle Gold Foil Watermark Texture & Ring Motifs */}
      <div className="absolute inset-0 pointer-events-none opacity-30 flex items-center justify-center">
        <svg width="420" height="420" viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="50" r="48" stroke="#C8A265" strokeWidth="0.5" strokeDasharray="3 3" />
          <circle cx="50" cy="50" r="42" stroke="#C8A265" strokeWidth="0.3" />
        </svg>
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        {/* Subtle Decorative Gold Star Anise Ornament */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <span className="w-12 h-[1px] bg-[#C8A265]" />
          <div className="text-[#C8A265]">
            <svg width="24" height="24" viewBox="0 0 40 40" fill="none">
              <polygon
                points="20,0 24,12 36,6 30,18 40,26 28,28 30,40 20,32 10,40 12,28 0,26 10,18 4,6 16,12"
                fill="#C8A265"
              />
              <circle cx="20" cy="20" r="3.5" fill="#F7F2E8" />
            </svg>
          </div>
          <span className="w-12 h-[1px] bg-[#C8A265]" />
        </div>

        {/* The Exact Signature Quote */}
        <blockquote className="font-serif-heading text-3xl sm:text-5xl lg:text-6xl font-normal leading-[1.25] text-[#1A1613] tracking-tight">
          “Good food is not just served. <br />
          <span className="italic font-display text-[#A07A3E]">It becomes a memory.”</span>
        </blockquote>

        {/* Minimalist Subtle Attribution */}
        <div className="mt-8 flex items-center justify-center gap-3">
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-[#7A6E60] font-medium">
            Masala Bistro · Tajganj · Agra
          </span>
        </div>
      </div>
    </section>
  );
};
