import React from 'react';
import { MapPin, Phone, Clock, Navigation, ExternalLink, Calendar, Car } from 'lucide-react';

interface LocationProps {
  onOpenReservation: () => void;
}

export const Location: React.FC<LocationProps> = ({ onOpenReservation }) => {
  const address = '304, Fatehabad Road, Vaibhav Nagar, Tajganj, Agra, Uttar Pradesh 282001';
  const phone = '+91 95577 61116';
  const googleMapsUrl =
    'https://www.google.com/maps/search/?api=1&query=Masala+Bistro+304+Fatehabad+Road+Vaibhav+Nagar+Tajganj+Agra+Uttar+Pradesh+282001';

  return (
    <section
      id="location"
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 bg-[#141210] overflow-hidden border-t border-[#26201B]"
    >
      {/* Background Ambience */}
      <div className="absolute top-1/2 left-10 w-96 h-96 bg-[#C8A265]/06 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        {/* Section Tag */}
        <div className="flex items-center gap-3 mb-4">
          <span className="h-[1px] w-10 bg-[#C8A265]" />
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-[#C8A265] font-semibold">
            Visit & Contact
          </span>
        </div>

        {/* Section Headline */}
        <div className="max-w-2xl mb-16">
          <h2 className="font-serif-heading text-3xl sm:text-5xl font-normal text-[#F8F4EC] tracking-tight">
            Find Us in Tajganj
          </h2>
          <p className="mt-4 text-[#A89E90] text-sm sm:text-base font-light">
            Conveniently situated along Fatehabad Road in Vaibhav Nagar, Tajganj — just minutes from Agra’s historic monument corridor.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Contact Cards, Exact Details & Direct Action Buttons */}
          <div className="lg:col-span-6 space-y-8">
            {/* Main Business Info Card */}
            <div className="p-8 rounded-2xl bg-[#1C1815] border border-[#C8A265]/30 shadow-xl space-y-6">
              <div>
                <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#C8A265]">
                  Multi-Cuisine Bistro
                </span>
                <h3 className="font-serif-heading text-3xl text-[#F8F4EC] font-semibold mt-1">
                  Masala Bistro
                </h3>
              </div>

              {/* Exact Address */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#2F2721]">
                <div className="w-10 h-10 rounded-full bg-[#C8A265]/15 flex items-center justify-center text-[#C8A265] shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans text-xs uppercase tracking-[0.16em] text-[#A89E90] mb-1">
                    Address
                  </h4>
                  <p className="font-serif-heading text-lg text-[#F8F4EC] font-normal leading-relaxed">
                    304, Fatehabad Road, <br />
                    Vaibhav Nagar, Tajganj, <br />
                    Agra, Uttar Pradesh 282001
                  </p>
                </div>
              </div>

              {/* Exact Phone */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#2F2721]">
                <div className="w-10 h-10 rounded-full bg-[#C05634]/15 flex items-center justify-center text-[#C05634] shrink-0 mt-0.5">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans text-xs uppercase tracking-[0.16em] text-[#A89E90] mb-1">
                    Telephone & Reservations
                  </h4>
                  <a
                    id="location-phone-link"
                    href={`tel:${phone.replace(/\s+/g, '')}`}
                    className="font-serif-heading text-2xl text-[#E5C384] hover:text-[#F8F4EC] transition-colors block"
                  >
                    {phone}
                  </a>
                  <p className="text-xs text-[#A89E90] mt-0.5">Direct reservations & takeaway orders</p>
                </div>
              </div>

              {/* Opening Hours */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#2F2721]">
                <div className="w-10 h-10 rounded-full bg-[#6E826F]/15 flex items-center justify-center text-[#6E826F] shrink-0 mt-0.5">
                  <Clock className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-sans text-xs uppercase tracking-[0.16em] text-[#A89E90]">
                    Dining Hours
                  </h4>
                  <p className="text-sm text-[#F8F4EC] font-medium">Monday – Sunday (All 7 Days)</p>
                  <p className="text-xs text-[#CDC5B8]">Lunch: 12:00 PM – 3:30 PM</p>
                  <p className="text-xs text-[#CDC5B8]">Dinner: 7:00 PM – 11:30 PM</p>
                </div>
              </div>

              {/* The Two Required Main Buttons */}
              <div className="pt-6 border-t border-[#2F2721] grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Open in Google Maps */}
                <a
                  id="open-google-maps-btn"
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-full bg-[#C8A265] text-[#141210] font-sans font-semibold text-xs uppercase tracking-[0.2em] transition-all hover:bg-[#E5C384] hover:shadow-lg shadow-black/40 text-center"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Open in Google Maps</span>
                </a>

                {/* Call Now */}
                <a
                  id="location-call-now-btn"
                  href={`tel:${phone.replace(/\s+/g, '')}`}
                  className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-full border border-[#C8A265]/50 bg-[#241E1A] text-[#F8F4EC] font-sans font-semibold text-xs uppercase tracking-[0.2em] transition-all hover:border-[#C8A265] hover:bg-[#C8A265]/15 text-center"
                >
                  <Phone className="w-4 h-4 text-[#C8A265]" />
                  <span>Call Now</span>
                </a>
              </div>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={onOpenReservation}
                  className="text-xs text-[#C8A265] hover:text-[#E5C384] underline underline-offset-4 tracking-wider uppercase font-medium cursor-pointer"
                >
                  Need a table reserved for a group or special dinner? Inquire here
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Elegant Stylized Map Illustration */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl overflow-hidden border border-[#C8A265]/35 bg-[#181411] p-6 shadow-2xl">
              {/* Map Header Bar */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-[#29221B]">
                <div className="flex items-center gap-2 text-xs text-[#CDC5B8]">
                  <Car className="w-4 h-4 text-[#C8A265]" />
                  <span>Fatehabad Road Arterial · Tajganj Sector</span>
                </div>
                <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#C8A265] bg-[#C8A265]/10 px-2.5 py-1 rounded-full border border-[#C8A265]/20">
                  Agra 282001
                </span>
              </div>

              {/* Stylized Architectural Map SVG with Pin */}
              <div className="relative w-full aspect-[4/3] rounded-2xl bg-[#12100E] border border-[#2E2721] overflow-hidden flex items-center justify-center">
                <svg
                  viewBox="0 0 600 450"
                  className="w-full h-full object-cover"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {/* Subtle Grid Lines */}
                  <defs>
                    <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <line x1="0" y1="0" x2="40" y2="0" stroke="#251F1A" strokeWidth="0.8" />
                      <line x1="0" y1="0" x2="0" y2="40" stroke="#251F1A" strokeWidth="0.8" />
                    </pattern>
                  </defs>
                  <rect width="600" height="450" fill="url(#mapGrid)" />

                  {/* Yamuna River Curve at the top */}
                  <path
                    d="M-20 40 Q250 80 620 30"
                    stroke="#1F2826"
                    strokeWidth="32"
                    fill="none"
                    strokeLinecap="round"
                    opacity="0.8"
                  />
                  <text x="320" y="52" fill="#6E826F" fontSize="12" letterSpacing="3" opacity="0.6">
                    YAMUNA RIVER
                  </text>

                  {/* Taj Mahal Monument Compound Icon & Outline */}
                  <g transform="translate(180, 75)">
                    <rect x="-10" y="-10" width="80" height="60" rx="6" fill="#1B1714" stroke="#C8A265" strokeWidth="1" opacity="0.6" />
                    <circle cx="30" cy="20" r="10" stroke="#C8A265" strokeWidth="1" fill="#241E1A" />
                    <text x="30" y="44" fill="#E5C384" fontSize="10" textAnchor="middle" letterSpacing="1">
                      TAJ MAHAL
                    </text>
                  </g>

                  {/* Arterial Roads */}
                  {/* Fatehabad Road (Main Spine) */}
                  <path
                    d="M-10 320 Q240 260 610 210"
                    stroke="#C8A265"
                    strokeWidth="8"
                    fill="none"
                    strokeOpacity="0.45"
                  />
                  <path
                    d="M-10 320 Q240 260 610 210"
                    stroke="#E5C384"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="8 8"
                    strokeOpacity="0.75"
                  />
                  <text x="140" y="325" fill="#E5C384" fontSize="11" letterSpacing="2" fontWeight="bold">
                    FATEHABAD ROAD
                  </text>

                  {/* Connecting Roads in Tajganj */}
                  <path d="M220 135 L260 265" stroke="#3A322A" strokeWidth="4" />
                  <path d="M380 90 L360 235" stroke="#3A322A" strokeWidth="4" />
                  <path d="M360 235 L330 390" stroke="#3A322A" strokeWidth="4" />
                  <path d="M120 280 L180 430" stroke="#3A322A" strokeWidth="3" />
                  <path d="M460 225 L510 380" stroke="#3A322A" strokeWidth="3" />

                  {/* Vaibhav Nagar Enclave */}
                  <rect x="290" y="225" width="110" height="70" rx="8" fill="#1E1915" stroke="#C8A265" strokeWidth="0.8" strokeDasharray="3 3" />
                  <text x="345" y="242" fill="#A89E90" fontSize="9" textAnchor="middle" letterSpacing="1">
                    VAIBHAV NAGAR
                  </text>

                  {/* Masala Bistro Precise Pin Location */}
                  <g transform="translate(345, 275)" className="cursor-pointer">
                    {/* Pulsing Target Rings */}
                    <circle cx="0" cy="0" r="28" fill="#C8A265" fillOpacity="0.15" className="animate-ping" style={{ animationDuration: '3s' }} />
                    <circle cx="0" cy="0" r="18" fill="#C05634" fillOpacity="0.25" />
                    
                    {/* Pin Shape */}
                    <path
                      d="M0 0 C-9 -9 -14 -18 -14 -26 C-14 -35 -7 -42 0 -42 C7 -42 14 -35 14 -26 C14 -18 9 -9 0 0 Z"
                      fill="#C8A265"
                      stroke="#141210"
                      strokeWidth="1.5"
                    />
                    <circle cx="0" cy="-26" r="5" fill="#141210" />
                    <circle cx="0" cy="-26" r="2.5" fill="#E5C384" />

                    {/* Pop-up Callout Label */}
                    <g transform="translate(0, -56)">
                      <rect x="-65" y="-18" width="130" height="24" rx="6" fill="#141210" stroke="#C8A265" strokeWidth="1.2" />
                      <text x="0" y="-3" fill="#F8F4EC" fontSize="10" fontWeight="bold" textAnchor="middle" letterSpacing="1">
                        MASALA BISTRO · 304
                      </text>
                    </g>
                  </g>

                  {/* Tajganj Context Label */}
                  <text x="210" y="195" fill="#8C8072" fontSize="10" letterSpacing="2">
                    TAJGANJ TOURIST ZONE
                  </text>
                </svg>

                {/* Live Distance Callout Pill */}
                <div className="absolute bottom-3 left-3 px-3 py-1.5 rounded-lg bg-[#141210]/90 backdrop-blur-md border border-[#C8A265]/30 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#C8A265]" />
                  <span className="text-[11px] text-[#E5C384] font-medium">
                    ~5-7 Mins from Taj Mahal East Gate
                  </span>
                </div>
              </div>

              {/* Map Footer Assistance */}
              <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#A89E90]">
                <span>Ample roadside & valet parking assistance available</span>
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#C8A265] hover:text-[#E5C384] flex items-center gap-1 font-medium"
                >
                  <span>Get Live Turn-by-Turn GPS</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
