import React, { useState } from 'react';
import { X, Phone, Calendar, Users, Clock, CheckCircle2, MessageSquare } from 'lucide-react';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [guests, setGuests] = useState('2 Guests');
  const [date, setDate] = useState('Today (Tonight)');
  const [time, setTime] = useState('8:00 PM');
  const [seating, setSeating] = useState('Romantic / Candlelight Corner');
  const [specialRequest, setSpecialRequest] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#161311] border border-[#C8A265]/40 rounded-2xl shadow-2xl overflow-hidden text-[#F8F4EC]">
        {/* Header */}
        <div className="p-6 border-b border-[#2C241E] flex items-center justify-between bg-[#1A1613]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.24em] text-[#C8A265]">
              Tajganj, Agra · Table Booking & Inquiries
            </span>
            <h3 className="font-serif-heading text-2xl text-[#F8F4EC] font-semibold">
              Reserve a Table
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full border border-[#3A3027] hover:border-[#C8A265] text-[#CDC5B8] hover:text-[#F8F4EC] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-[#C8A265]/15 border border-[#C8A265] flex items-center justify-center mx-auto text-[#E5C384]">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h4 className="font-serif-heading text-2xl text-[#F8F4EC]">
              Reservation Request Received
            </h4>

            <p className="text-sm text-[#CDC5B8] font-light max-w-md mx-auto leading-relaxed">
              Thank you, <strong className="text-[#F8F4EC]">{name || 'valued guest'}</strong>.
              Our team at Masala Bistro has received your reservation inquiry for{' '}
              <strong className="text-[#E5C384]">{guests}</strong> on{' '}
              <strong className="text-[#E5C384]">{date} at {time}</strong>.
            </p>

            <div className="p-4 rounded-xl bg-[#1F1A17] border border-[#382F27] text-xs text-[#A89E90] text-left max-w-md mx-auto space-y-1">
              <p>📍 Location: 304, Fatehabad Road, Vaibhav Nagar, Tajganj, Agra</p>
              <p>📞 Confirmed via Phone: {phone || '+91 95577 61116'}</p>
              <p>🪑 Seating: {seating}</p>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href="tel:+919557761116"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-[#C8A265] text-[#141210] font-sans font-bold text-xs uppercase tracking-wider"
              >
                <Phone className="w-4 h-4" />
                <span>Call Restaurant Now</span>
              </a>

              <button
                type="button"
                onClick={handleReset}
                className="w-full sm:w-auto px-6 py-3 rounded-full border border-[#382F27] text-xs text-[#CDC5B8] hover:text-[#F8F4EC]"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
            {/* Quick Call Header Banner */}
            <div className="p-3.5 rounded-xl bg-[#211B17] border border-[#C8A265]/30 flex items-center justify-between text-xs">
              <span className="text-[#CDC5B8]">Need immediate table confirmation?</span>
              <a
                href="tel:+919557761116"
                className="font-bold text-[#E5C384] hover:underline flex items-center gap-1"
              >
                <Phone className="w-3 h-3" />
                <span>+91 95577 61116</span>
              </a>
            </div>

            {/* Inputs: Name and Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                  Guest Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Arjun Sharma"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                  Phone Number
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
                />
              </div>
            </div>

            {/* Guests and Date */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                  Party Size
                </label>
                <select
                  value={guests}
                  onChange={(e) => setGuests(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
                >
                  <option value="1 Guest">1 Guest</option>
                  <option value="2 Guests">2 Guests (Couple)</option>
                  <option value="3-4 Guests">3-4 Guests</option>
                  <option value="5-6 Guests">5-6 Guests</option>
                  <option value="7-10 Guests">7-10 Guests (Family)</option>
                  <option value="10+ Guests">10+ (Large Gathering)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                  Date
                </label>
                <select
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
                >
                  <option value="Today">Today</option>
                  <option value="Tomorrow">Tomorrow</option>
                  <option value="This Friday">This Friday</option>
                  <option value="This Saturday">This Saturday</option>
                  <option value="This Sunday">This Sunday</option>
                  <option value="Upcoming Week">Upcoming Week</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                  Time Slot
                </label>
                <select
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
                >
                  <option value="12:30 PM (Lunch)">12:30 PM (Lunch)</option>
                  <option value="1:30 PM (Lunch)">1:30 PM (Lunch)</option>
                  <option value="2:30 PM (Lunch)">2:30 PM (Lunch)</option>
                  <option value="7:30 PM (Dinner)">7:30 PM (Dinner)</option>
                  <option value="8:00 PM (Dinner)">8:00 PM (Dinner)</option>
                  <option value="8:45 PM (Dinner)">8:45 PM (Dinner)</option>
                  <option value="9:30 PM (Dinner)">9:30 PM (Dinner)</option>
                  <option value="10:15 PM (Dinner)">10:15 PM (Dinner)</option>
                </select>
              </div>
            </div>

            {/* Seating Preference */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                Atmosphere / Seating Preference
              </label>
              <select
                value={seating}
                onChange={(e) => setSeating(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none"
              >
                <option value="Romantic / Candlelight Corner">Romantic / Candlelight Corner</option>
                <option value="Main Bistro Floor">Main Bistro Floor</option>
                <option value="Family Gathering Booth">Family Gathering Booth</option>
                <option value="Quiet Corner Table">Quiet Corner Table</option>
              </select>
            </div>

            {/* Special Request */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#A89E90] mb-1.5 font-medium">
                Special Requests or Dietary Requirements
              </label>
              <textarea
                rows={2}
                value={specialRequest}
                onChange={(e) => setSpecialRequest(e.target.value)}
                placeholder="Anniversary, birthday, less spicy preferences, Jain meal requirements..."
                className="w-full px-4 py-2 rounded-xl bg-[#120F0D] border border-[#302720] focus:border-[#C8A265] text-sm text-[#F8F4EC] focus:outline-none placeholder:text-[#5E5448]"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-full bg-[#C8A265] text-[#141210] font-sans font-bold text-xs uppercase tracking-[0.22em] hover:bg-[#E5C384] transition-all shadow-lg shadow-[#C8A265]/20 cursor-pointer"
              >
                Confirm Table Inquiry
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
