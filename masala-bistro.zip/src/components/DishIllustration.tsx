import React from 'react';
import { MenuCategory } from '../data/menuData';

interface DishIllustrationProps {
  category: MenuCategory;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const DishIllustration: React.FC<DishIllustrationProps> = ({
  category,
  className = '',
  size = 'md',
}) => {
  const dimensions = {
    sm: { w: 90, h: 90 },
    md: { w: 140, h: 140 },
    lg: { w: 200, h: 200 },
  }[size];

  const renderGraphic = () => {
    switch (category) {
      case 'Indian Favourites':
        return (
          // Copper Kadhai + Dal Makhani / Curry Swirls + Star Anise + Steam
          <g>
            <defs>
              <linearGradient id="kadhaiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#C05634" />
                <stop offset="50%" stopColor="#8F3419" />
                <stop offset="100%" stopColor="#5E1F0E" />
              </linearGradient>
              <linearGradient id="curryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#E5983A" />
                <stop offset="60%" stopColor="#C05634" />
                <stop offset="100%" stopColor="#8A2E14" />
              </linearGradient>
            </defs>

            {/* Background Warm Ambient Aura */}
            <circle cx="50" cy="50" r="44" fill="#C05634" fillOpacity="0.08" />
            <circle cx="50" cy="50" r="38" stroke="#C8A265" strokeWidth="0.75" strokeDasharray="4 4" opacity="0.4" />

            {/* Aromatic Steam Trails */}
            <path d="M43 32 C41 24, 46 20, 44 14" stroke="#C8A265" strokeWidth="1.5" strokeLinecap="round" opacity="0.7" className="animate-steam" />
            <path d="M52 30 C55 22, 49 18, 54 11" stroke="#E5C384" strokeWidth="1.8" strokeLinecap="round" opacity="0.85" className="animate-steam" style={{ animationDelay: '1s' }} />
            <path d="M60 33 C58 25, 63 21, 61 15" stroke="#C8A265" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" className="animate-steam" style={{ animationDelay: '2s' }} />

            {/* Kadhai Handles */}
            <path d="M16 54 C10 50, 10 64, 18 60" stroke="#C8A265" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M84 54 C90 50, 90 64, 82 60" stroke="#C8A265" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            {/* Copper Kadhai Bowl Body */}
            <path d="M20 54 C20 78, 80 78, 80 54 Z" fill="url(#kadhaiGrad)" stroke="#C8A265" strokeWidth="1.5" />
            {/* Inner Curry Surface */}
            <ellipse cx="50" cy="54" rx="28" ry="12" fill="url(#curryGrad)" stroke="#E5C384" strokeWidth="0.8" />

            {/* Fresh Cream Swirl & Cilantro */}
            <path d="M38 53 C43 50, 56 50, 62 55 C58 58, 48 57, 44 54" stroke="#F8F4EC" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.85" />
            {/* Cilantro Leaf */}
            <circle cx="50" cy="53" r="2.5" fill="#6E826F" />
            <path d="M47 52 C45 49, 52 48, 51 52 Z" fill="#6E826F" />

            {/* Floating Whole Spices (Star Anise & Cardamom) */}
            <g transform="translate(68, 38) rotate(20) scale(0.6)">
              <polygon points="10,0 12,6 18,3 15,9 20,13 14,14 15,20 10,16 5,20 6,14 0,13 5,9 2,3 8,6" fill="#C8A265" opacity="0.85" />
            </g>
          </g>
        );

      case 'Mughlai':
        return (
          // Royal Handi Vessel with Saffron Petals & Almonds
          <g>
            <defs>
              <linearGradient id="mughlaiGold" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#F8E5BA" />
                <stop offset="50%" stopColor="#C8A265" />
                <stop offset="100%" stopColor="#8A672E" />
              </linearGradient>
              <linearGradient id="kormaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#D8A058" />
                <stop offset="50%" stopColor="#B37834" />
                <stop offset="100%" stopColor="#693C0F" />
              </linearGradient>
            </defs>

            {/* Regal Halo */}
            <circle cx="50" cy="50" r="44" fill="#C8A265" fillOpacity="0.08" />
            <circle cx="50" cy="50" r="41" stroke="#C8A265" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.5" />

            {/* Delicate Fragrance Smoke */}
            <path d="M47 28 C45 20, 52 16, 50 10" stroke="#E5C384" strokeWidth="1.8" strokeLinecap="round" opacity="0.85" className="animate-steam" />
            <path d="M55 26 C57 19, 53 14, 56 9" stroke="#C8A265" strokeWidth="1.4" strokeLinecap="round" opacity="0.65" className="animate-steam" style={{ animationDelay: '1.5s' }} />

            {/* Ornate Handi Neck & Base */}
            <path d="M30 46 C30 43, 70 43, 70 46 L66 52 C76 60, 72 76, 50 76 C28 76, 24 60, 34 52 Z" fill="#241E1A" stroke="url(#mughlaiGold)" strokeWidth="1.6" />
            
            {/* Rich Korma Liquid & Saffron Strands */}
            <ellipse cx="50" cy="47" rx="18" ry="6" fill="url(#kormaGrad)" stroke="#E5C384" strokeWidth="0.8" />
            {/* Saffron Strands */}
            <path d="M45 47 Q48 44 52 46" stroke="#C05634" strokeWidth="1.2" strokeLinecap="round" />
            <path d="M49 46 Q53 48 56 46" stroke="#C05634" strokeWidth="1.2" strokeLinecap="round" />

            {/* Filigree Crown Pattern on Handi Body */}
            <path d="M38 62 Q50 67 62 62" stroke="url(#mughlaiGold)" strokeWidth="1.2" strokeDasharray="2 3" fill="none" />
            <circle cx="50" cy="65" r="2.5" fill="#C8A265" />
            <circle cx="43" cy="63" r="1.5" fill="#E5C384" />
            <circle cx="57" cy="63" r="1.5" fill="#E5C384" />

            {/* Slivered Almond Leaves */}
            <path d="M26 34 C24 30, 28 26, 32 29 C34 33, 29 36, 26 34 Z" fill="#E5C384" opacity="0.8" />
            <path d="M72 32 C74 28, 70 24, 66 27 C64 31, 69 34, 72 32 Z" fill="#E5C384" opacity="0.8" />
          </g>
        );

      case 'Tandoori & Kebab':
        return (
          // Charcoal Skewers + Embers + Mint Chutney + Lime
          <g>
            <defs>
              <linearGradient id="tandoorChar" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#D96B43" />
                <stop offset="50%" stopColor="#963116" />
                <stop offset="100%" stopColor="#3B1207" />
              </linearGradient>
            </defs>

            {/* Ember Glow Background */}
            <circle cx="50" cy="50" r="44" fill="#B34928" fillOpacity="0.1" />
            <circle cx="50" cy="50" r="39" stroke="#B34928" strokeWidth="0.8" opacity="0.4" />

            {/* Skewer Rods Crossing */}
            <line x1="18" y1="82" x2="82" y2="18" stroke="#C8A265" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="22" y1="18" x2="78" y2="82" stroke="#8A672E" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />

            {/* Charred Kebab Cubes */}
            {/* Kebab 1 */}
            <rect x="29" y="59" width="14" height="14" rx="3" transform="rotate(-45 36 66)" fill="url(#tandoorChar)" stroke="#C8A265" strokeWidth="1" />
            <line x1="33" y1="63" x2="39" y2="69" stroke="#161311" strokeWidth="1.5" strokeLinecap="round" />
            
            {/* Kebab 2 (Center) */}
            <rect x="43" y="43" width="16" height="16" rx="4" transform="rotate(-45 51 51)" fill="url(#tandoorChar)" stroke="#E5C384" strokeWidth="1.2" />
            <line x1="47" y1="48" x2="55" y2="56" stroke="#161311" strokeWidth="1.8" strokeLinecap="round" />
            <line x1="49" y1="44" x2="57" y2="52" stroke="#161311" strokeWidth="1.2" strokeLinecap="round" />

            {/* Kebab 3 */}
            <rect x="57" y="27" width="14" height="14" rx="3" transform="rotate(-45 64 34)" fill="url(#tandoorChar)" stroke="#C8A265" strokeWidth="1" />
            <line x1="61" y1="31" x2="67" y2="37" stroke="#161311" strokeWidth="1.5" strokeLinecap="round" />

            {/* Fresh Lime Wedge */}
            <g transform="translate(68, 62) scale(0.9)">
              <path d="M0 12 A12 12 0 0 1 12 0 L0 0 Z" fill="#8FA390" stroke="#C8A265" strokeWidth="1" />
              <path d="M2 10 A9 9 0 0 1 10 2 L2 2 Z" fill="#6E826F" opacity="0.6" />
            </g>

            {/* Mint Chutney Dot */}
            <circle cx="28" cy="36" r="5" fill="#6E826F" stroke="#C8A265" strokeWidth="0.8" />
            <circle cx="27" cy="35" r="1.5" fill="#8FA390" />

            {/* Charcoal Embers */}
            <circle cx="42" cy="74" r="1.5" fill="#D96B43" />
            <circle cx="62" cy="68" r="2" fill="#D96B43" />
          </g>
        );

      case 'Chinese & Asian':
        return (
          // High-flame Wok + Tossed Noodles + Scallions
          <g>
            <defs>
              <linearGradient id="asianWok" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38322D" />
                <stop offset="50%" stopColor="#211D1A" />
                <stop offset="100%" stopColor="#14110F" />
              </linearGradient>
            </defs>

            {/* Sage Green Fresh Aura */}
            <circle cx="50" cy="50" r="44" fill="#6E826F" fillOpacity="0.08" />
            <circle cx="50" cy="50" r="39" stroke="#6E826F" strokeWidth="0.8" strokeDasharray="4 4" opacity="0.5" />

            {/* Wok Silhouette */}
            <path d="M22 48 C22 74, 78 74, 78 48 Z" fill="url(#asianWok)" stroke="#C8A265" strokeWidth="1.5" />
            <path d="M76 48 L88 44" stroke="#C8A265" strokeWidth="3.5" strokeLinecap="round" />

            {/* Swirled Tossed Noodles */}
            <path d="M30 48 Q44 38 52 46 T68 44" stroke="#E5C384" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M34 52 Q48 42 56 50 T70 48" stroke="#D8B574" strokeWidth="2" strokeLinecap="round" fill="none" />
            <path d="M32 44 Q42 32 50 40 T62 36" stroke="#F4EFE6" strokeWidth="1.8" strokeLinecap="round" fill="none" />

            {/* Pair of Sleek Chopsticks */}
            <line x1="72" y1="16" x2="44" y2="52" stroke="#C8A265" strokeWidth="2" strokeLinecap="round" />
            <line x1="76" y1="16" x2="48" y2="54" stroke="#8A672E" strokeWidth="1.8" strokeLinecap="round" />

            {/* Tossed Scallions & Red Chillies */}
            <rect x="42" y="34" width="7" height="2" rx="1" transform="rotate(-25 42 34)" fill="#6E826F" />
            <rect x="54" y="38" width="6" height="2" rx="1" transform="rotate(35 54 38)" fill="#6E826F" />
            <circle cx="48" cy="46" r="1.5" fill="#C05634" />
            <circle cx="58" cy="48" r="1.2" fill="#C05634" />
            {/* White Sesame Seeds */}
            <circle cx="38" cy="48" r="0.9" fill="#F8F4EC" />
            <circle cx="64" cy="44" r="0.9" fill="#F8F4EC" />
          </g>
        );

      case 'Rolls & Fast Food':
        return (
          // Crisp Kathi Roll + Pickled Onions + Herb Butter
          <g>
            <defs>
              <linearGradient id="rollGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#E5C384" />
                <stop offset="50%" stopColor="#C8A265" />
                <stop offset="100%" stopColor="#966C2E" />
              </linearGradient>
            </defs>

            {/* Warm Terracotta Aura */}
            <circle cx="50" cy="50" r="44" fill="#D96B43" fillOpacity="0.09" />
            <circle cx="50" cy="50" r="39" stroke="#C8A265" strokeWidth="0.8" opacity="0.4" />

            {/* Kathi Roll Cylinder Body */}
            <g transform="rotate(-30 50 50)">
              {/* Parchment Wrapper Base */}
              <rect x="34" y="48" width="32" height="32" rx="4" fill="#241E1A" stroke="#C8A265" strokeWidth="1.2" />
              <line x1="38" y1="56" x2="62" y2="56" stroke="#C8A265" strokeWidth="0.75" strokeDasharray="3 3" />
              
              {/* Golden Flaky Paratha Roll */}
              <path d="M36 28 C36 22, 64 22, 64 28 L64 52 L36 52 Z" fill="url(#rollGrad)" stroke="#8A672E" strokeWidth="1" />
              
              {/* Flaky Griddle Markings */}
              <line x1="40" y1="36" x2="52" y2="34" stroke="#8A4A1C" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="46" y1="42" x2="60" y2="40" stroke="#8A4A1C" strokeWidth="1.5" strokeLinecap="round" />

              {/* Roll Open Top with Spiced Fillings */}
              <ellipse cx="50" cy="27" rx="14" ry="6" fill="#782E18" stroke="#E5C384" strokeWidth="0.8" />
              {/* Fillings: Paneer/Chicken tikka & mint */}
              <circle cx="46" cy="27" r="3" fill="#D96B43" />
              <circle cx="53" cy="26" r="2.5" fill="#6E826F" />
              <circle cx="50" cy="28" r="2" fill="#F8F4EC" />
            </g>

            {/* Pickled Onion Rings Accent */}
            <circle cx="28" cy="64" r="6" stroke="#C05634" strokeWidth="1.5" fill="none" opacity="0.8" />
            <circle cx="70" cy="34" r="5" stroke="#C05634" strokeWidth="1.5" fill="none" opacity="0.8" />
          </g>
        );

      case 'Continental':
        return (
          // Durum Pasta Swirl + Olive Oil Droplet + Fresh Basil
          <g>
            <defs>
              <linearGradient id="plateGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#2A241F" />
                <stop offset="100%" stopColor="#191513" />
              </linearGradient>
            </defs>

            {/* Muted Gold Ambient Halo */}
            <circle cx="50" cy="50" r="44" fill="#9E7B42" fillOpacity="0.08" />
            <circle cx="50" cy="50" r="40" stroke="#C8A265" strokeWidth="0.8" strokeDasharray="6 3" opacity="0.5" />

            {/* Minimalist Fine Ceramic Plate Rim */}
            <circle cx="50" cy="50" r="34" fill="url(#plateGrad)" stroke="#C8A265" strokeWidth="1.4" />
            <circle cx="50" cy="50" r="24" stroke="#C8A265" strokeWidth="0.6" strokeOpacity="0.4" fill="#1C1815" />

            {/* Elegant Twirled Pasta Nest */}
            <path d="M42 45 C38 52, 48 58, 54 55 C60 52, 58 44, 50 42 C44 40, 43 48, 48 50 C52 52, 56 48, 54 45" stroke="#E5C384" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M40 50 C46 56, 56 54, 58 47" stroke="#D8B574" strokeWidth="2" strokeLinecap="round" fill="none" />

            {/* Fresh Basil Leaves */}
            <path d="M50 38 C46 34, 50 30, 54 33 C56 37, 53 39, 50 38 Z" fill="#6E826F" stroke="#8FA390" strokeWidth="0.6" />
            <path d="M53 41 C57 39, 61 42, 59 45 C56 47, 54 44, 53 41 Z" fill="#6E826F" stroke="#8FA390" strokeWidth="0.6" />

            {/* Cracked Black Peppercorn & Olive Oil Droplet */}
            <circle cx="38" cy="42" r="1" fill="#C8A265" />
            <circle cx="62" cy="52" r="1.2" fill="#C8A265" />
            <circle cx="45" cy="58" r="1.5" fill="#E5C384" opacity="0.85" />
          </g>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`inline-flex items-center justify-center ${className}`}>
      <svg
        width={dimensions.w}
        height={dimensions.h}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-500 hover:scale-105"
      >
        {renderGraphic()}
      </svg>
    </div>
  );
};
