import React, { useState } from 'react';
import { Logo } from './Logo';
import { Phone, MapPin, ArrowUp, Mail, CheckCircle, ArrowRight } from 'lucide-react';

interface FooterProps {
  onOpenReservation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenReservation }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    setErrorMsg('');
    setSubscribed(true);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const footerNav = [
    { name: 'Home', href: '#' },
    { name: 'Our Story', href: '#story' },
    { name: 'Menu', href: '#menu' },
    { name: 'Experience', href: '#experience' },
    { name: 'Visit', href: '#location' },
    { name: 'Call', href: 'tel:+919557761116' },
  ];

  return (
    <footer className="relative bg-[#0E0C0A] text-[#CDC5B8] pt-20 pb-12 px-4 sm:px-6 lg:px-8 border-t border-[#241E19] overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-24 bg-[#C8A265]/05 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        {/* Brand & Direct Contact Row */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-[#241E19]">
          {/* Brand Presentation */}
          <div className="space-y-3">
            <Logo size="lg" variant="light" />
            <p className="font-serif italic text-lg text-[#E5C384] tracking-wide pt-2">
              “Indian warmth. Modern appetite.”
            </p>
            <p className="text-xs text-[#8F8475] max-w-sm">
              304, Fatehabad Road, Vaibhav Nagar, Tajganj, Agra, Uttar Pradesh 282001
            </p>
          </div>

          {/* Quick Connect Actions */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <a
              id="footer-call-btn"
              href="tel:+919557761116"
              className="flex items-center gap-3 px-5 py-3 rounded-full border border-[#C8A265]/40 bg-[#191512] text-[#F8F4EC] hover:border-[#C8A265] hover:bg-[#C8A265]/10 transition-all text-xs tracking-wider"
            >
              <Phone className="w-4 h-4 text-[#C8A265]" />
              <span>+91 95577 61116</span>
            </a>

            <button
              type="button"
              onClick={onOpenReservation}
              className="px-6 py-3 rounded-full bg-[#C8A265] text-[#141210] font-sans font-semibold text-xs uppercase tracking-[0.2em] hover:bg-[#E5C384] transition-all cursor-pointer"
            >
              Reserve Table
            </button>
          </div>
        </div>

        {/* Discreet Stylish Newsletter Signup Section with Gold-Accented Input */}
        <div className="py-10 border-b border-[#241E19]">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <div className="inline-flex items-center gap-2">
              <span className="w-5 h-[1px] bg-[#C8A265]/50" />
              <span className="text-[10px] font-sans uppercase tracking-[0.3em] text-[#C8A265] font-semibold">
                Masala Bistro Circle
              </span>
              <span className="w-5 h-[1px] bg-[#C8A265]/50" />
            </div>

            <h4 className="font-serif-heading text-xl sm:text-2xl text-[#F8F4EC] font-normal tracking-wide">
              Receive Seasonal Flavours & Private Tasting Privileges
            </h4>
            <p className="text-xs text-[#A89E90] max-w-lg mx-auto font-light leading-relaxed">
              Join our private guest list for quiet notifications on new seasonal dishes, festival menus, and exclusive dining offers in Tajganj.
            </p>

            {subscribed ? (
              <div className="p-4 rounded-xl bg-[#1A1512] border border-[#C8A265]/40 text-xs text-[#E5C384] inline-flex items-center gap-2.5 animate-in fade-in duration-300">
                <CheckCircle className="w-4 h-4 text-[#C8A265] shrink-0" />
                <span>Thank you for subscribing. We look forward to welcoming you with special offers.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="pt-2 max-w-md mx-auto">
                <div className="relative flex items-center">
                  <div className="absolute left-4 text-[#C8A265]/70 pointer-events-none">
                    <Mail className="w-4 h-4" />
                  </div>

                  {/* Gold-Accented Input Field */}
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errorMsg) setErrorMsg('');
                    }}
                    placeholder="Enter your email for future bistro offers..."
                    className="w-full pl-11 pr-32 py-3 rounded-full bg-[#161311] border border-[#C8A265]/45 text-[#F8F4EC] placeholder:text-[#807466] text-xs focus:outline-none focus:border-[#C8A265] focus:ring-1 focus:ring-[#C8A265] transition-all"
                  />

                  {/* Subscribe Button */}
                  <button
                    type="submit"
                    className="absolute right-1.5 top-1.5 bottom-1.5 px-5 rounded-full bg-[#C8A265] hover:bg-[#E5C384] text-[#141210] font-sans text-[11px] font-semibold uppercase tracking-wider transition-all duration-200 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Join</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {errorMsg && (
                  <p className="text-[11px] text-[#C05634] mt-1.5 text-left pl-4 font-light">
                    {errorMsg}
                  </p>
                )}

                <p className="text-[10px] text-[#73685C] mt-2 tracking-wide">
                  Discreet communication only. Unsubscribe anytime with a single click.
                </p>
              </form>
            )}
          </div>
        </div>

        {/* Navigation Links Row */}
        <div className="py-8 flex flex-wrap items-center justify-between gap-6 border-b border-[#241E19]">
          <nav className="flex flex-wrap items-center gap-6 sm:gap-8">
            {footerNav.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="font-sans text-xs uppercase tracking-[0.2em] text-[#A89E90] hover:text-[#C8A265] transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          <button
            type="button"
            onClick={scrollToTop}
            className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#8F8475] hover:text-[#C8A265] transition-colors cursor-pointer"
            aria-label="Back to top"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Legal & Exact Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7A6F62]">
          <p>© 2026 Masala Bistro · Agra</p>
          <p className="text-[11px] tracking-wider text-[#5A5147]">
            Crafted for Tajganj, Agra · Multi-Cuisine Dining & Hospitality
          </p>
        </div>
      </div>
    </footer>
  );
};
