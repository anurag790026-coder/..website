import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Story } from './components/Story';
import { MenuShowcase } from './components/MenuShowcase';
import { Experience } from './components/Experience';
import { SignatureQuote } from './components/SignatureQuote';
import { Location } from './components/Location';
import { Footer } from './components/Footer';
import { FullMenuModal } from './components/FullMenuModal';
import { ReservationModal } from './components/ReservationModal';
import { MobileActionBar } from './components/MobileActionBar';

export default function App() {
  const [reservationModalOpen, setReservationModalOpen] = useState(false);
  const [fullMenuModalOpen, setFullMenuModalOpen] = useState(false);

  const handleExploreMenu = () => {
    const menuSection = document.getElementById('menu');
    if (menuSection) {
      menuSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleGetDirections = () => {
    const locationSection = document.getElementById('location');
    if (locationSection) {
      locationSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#141210] text-[#F4EFE6] font-sans selection:bg-[#C8A265]/30 selection:text-[#F8F4EC]">
      {/* 1. Transparent to Solid Sticky Navigation */}
      <Navbar
        onOpenReservation={() => setReservationModalOpen(true)}
        onOpenFullMenu={() => setFullMenuModalOpen(true)}
      />

      {/* 2. Dramatic Full-Screen Hero Section */}
      <main>
        <Hero
          onExploreMenu={handleExploreMenu}
          onGetDirections={handleGetDirections}
        />

        {/* 3. Our Story Section */}
        <Story />

        {/* 4. Visually Impressive Menu Section */}
        <MenuShowcase
          onOpenFullMenu={() => setFullMenuModalOpen(true)}
          onOpenReservation={() => setReservationModalOpen(true)}
        />

        {/* 5. Dark Luxury Experience Section */}
        <Experience
          onOpenReservation={() => setReservationModalOpen(true)}
        />

        {/* 6. Minimalist Signature Quote Section */}
        <SignatureQuote />

        {/* 7. Sophisticated Location & Contact Section */}
        <Location
          onOpenReservation={() => setReservationModalOpen(true)}
        />
      </main>

      {/* 8. Premium Dark Footer */}
      <Footer
        onOpenReservation={() => setReservationModalOpen(true)}
      />

      {/* Comprehensive Full Menu Catalog Dialog */}
      <FullMenuModal
        isOpen={fullMenuModalOpen}
        onClose={() => setFullMenuModalOpen(false)}
        onOpenReservation={() => setReservationModalOpen(true)}
      />

      {/* Table Reservation & Inquiry Booking Dialog */}
      <ReservationModal
        isOpen={reservationModalOpen}
        onClose={() => setReservationModalOpen(false)}
      />

      {/* Mobile-Friendly Fixed Action Bar (Call Now, Directions, Menu, Reserve) */}
      <MobileActionBar
        onOpenFullMenu={() => setFullMenuModalOpen(true)}
        onOpenReservation={() => setReservationModalOpen(true)}
      />
    </div>
  );
}
